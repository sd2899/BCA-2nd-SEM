import Map "mo:core/Map";
import Text "mo:core/Text";
import Time "mo:core/Time";
import List "mo:core/List";
import Runtime "mo:core/Runtime";
import Order "mo:core/Order";
import Nat "mo:core/Nat";
import Int "mo:core/Int";

actor {
  type User = {
    email : Text;
    passwordHash : Text;
  };

  type LabDifficulty = {
    #Easy;
    #Medium;
    #Hard;
    #Extreme;
  };

  type LabTool = {
    name : Text;
    description : Text;
  };

  type LabSummary = {
    id : Nat;
    name : Text;
    difficulty : LabDifficulty;
    estimatedDuration : Nat;
  };

  type LabDetail = {
    id : Nat;
    name : Text;
    difficulty : LabDifficulty;
    description : Text;
    tools : [LabTool];
    howToUse : Text;
    estimatedDuration : Nat;
  };

  type LabStatus = {
    #Idle;
    #Running;
    #Stopped;
    #Destroyed;
  };

  type LabInstance = {
    userEmail : Text;
    labId : Nat;
    status : LabStatus;
    startTime : ?Int;
    containerId : ?Text;
  };

  type UserStats = {
    activeSessions : Nat;
    stoppedSessions : Nat;
    completedSessions : Nat;
    totalLabsLaunched : Nat;
  };

  module TextNatTuple {
    public func compare((text1, nat1) : (Text, Nat), (text2, nat2) : (Text, Nat)) : Order.Order {
      switch (Text.compare(text1, text2)) {
        case (#less) { #less };
        case (#greater) { #greater };
        case (#equal) { Nat.compare(nat1, nat2) };
      };
    };
  };

  type SessionToken = Text;

  type LoginResult = {
    token : SessionToken;
    user : User;
  };

  let users = Map.empty<Text, User>();
  let labs = Map.empty<Nat, LabDetail>();
  let sessions = Map.empty<SessionToken, Text>();
  let labInstances = Map.empty<(Text, Nat), LabInstance>();
  var nextLabId : Nat = 6;

  // Seed users and labs on first deploy
  do {
    users.add("admin@cyberrange.io", { email = "admin@cyberrange.io"; passwordHash = "Admin@123" });
    users.add("user@cyberrange.io", { email = "user@cyberrange.io"; passwordHash = "User@123" });

    let labDetails = [
      {
        id = 1;
        name = "Intro to Kali Linux";
        difficulty = #Easy;
        description = "Basic lab to get familiar with Kali Linux tools.";
        tools = [
          { name = "Nmap"; description = "Network scanning tool." },
          { name = "Wireshark"; description = "Packet analyzer tool." },
        ];
        howToUse = "Follow instructions to use Nmap and Wireshark in Kali.";
        estimatedDuration = 60;
      },
      {
        id = 2;
        name = "Web App Pentest";
        difficulty = #Medium;
        description = "Simulated web application for penetration testing.";
        tools = [
          { name = "Burp Suite"; description = "Web proxy analyzer." },
          { name = "SQLMap"; description = "SQL injection testing tool." },
        ];
        howToUse = "Use Burp Suite to intercept traffic and test for vulnerabilities.";
        estimatedDuration = 90;
      },
      {
        id = 3;
        name = "Active Directory Attack";
        difficulty = #Hard;
        description = "Test attacking Windows Active Directory environment.";
        tools = [
          { name = "BloodHound"; description = "AD enumeration tool." },
          { name = "Mimikatz"; description = "Credential dumping tool." },
        ];
        howToUse = "Enumerate AD using BloodHound, use Mimikatz for privilege escalation.";
        estimatedDuration = 120;
      },
      {
        id = 4;
        name = "Red Team Engagement";
        difficulty = #Extreme;
        description = "Simulate full-scale Red Team attack scenario.";
        tools = [
          { name = "Cobalt Strike"; description = "Post-exploitation framework." },
          { name = "C2 Servers"; description = "Command and control infrastructure." },
        ];
        howToUse = "Use Cobalt Strike to compromise hosts and maintain persistence.";
        estimatedDuration = 180;
      },
      {
        id = 5;
        name = "Network Forensics";
        difficulty = #Medium;
        description = "Analyze network traffic captures for security incidents.";
        tools = [
          { name = "Wireshark"; description = "Packet capture analysis." },
          { name = "Bro"; description = "Network security monitoring." },
        ];
        howToUse = "Inspect PCAP data for malicious activity using Wireshark and Bro.";
        estimatedDuration = 75;
      },
    ];

    for (lab in labDetails.values()) {
      labs.add(lab.id, lab);
    };
  };

  func validateToken(token : SessionToken) : Text {
    switch (sessions.get(token)) {
      case (null) { Runtime.trap("Invalid token") };
      case (?userEmail) { userEmail };
    };
  };

  func validateAdminToken(token : SessionToken) : () {
    let userEmail = validateToken(token);
    if (not Text.equal(userEmail, "admin@cyberrange.io")) {
      Runtime.trap("Unauthorized: Admin access required");
    };
  };

  public shared func login(email : Text, password : Text) : async LoginResult {
    switch (users.get(email)) {
      case (null) { Runtime.trap("Invalid credentials") };
      case (?user) {
        if (Text.equal(user.passwordHash, password)) {
          let token = email # "_" # Time.now().toText();
          sessions.add(token, email);
          { token; user };
        } else {
          Runtime.trap("Invalid credentials");
        };
      };
    };
  };

  public query func getLabs(token : SessionToken) : async [LabSummary] {
    ignore validateToken(token);
    labs.values().toArray().map(
      func(lab) {
        {
          id = lab.id;
          name = lab.name;
          difficulty = lab.difficulty;
          estimatedDuration = lab.estimatedDuration;
        };
      }
    );
  };

  public query func getLabDetail(token : SessionToken, labId : Nat) : async LabDetail {
    ignore validateToken(token);
    switch (labs.get(labId)) {
      case (null) { Runtime.trap("Lab not found") };
      case (?lab) { lab };
    };
  };

  public shared func launchLab(token : SessionToken, labId : Nat) : async LabInstance {
    let userEmail = validateToken(token);
    switch (labs.get(labId)) {
      case (null) { Runtime.trap("Lab not found") };
      case (?_lab) {};
    };
    let containerId = "container_" # userEmail # "_" # labId.toText();

    let startTime = switch (labInstances.get((userEmail, labId))) {
      case (?existing) {
        switch (existing.status) {
          case (#Stopped) { existing.startTime };
          case (_) { ?Time.now() };
        };
      };
      case (null) { ?Time.now() };
    };

    let instance : LabInstance = {
      userEmail;
      labId;
      status = #Running;
      startTime;
      containerId = ?containerId;
    };
    labInstances.add((userEmail, labId), instance);
    instance;
  };

  public shared func stopLab(token : SessionToken, labId : Nat) : async LabInstance {
    let userEmail = validateToken(token);
    switch (labInstances.get((userEmail, labId))) {
      case (null) { Runtime.trap("Lab not running") };
      case (?instance) {
        if (instance.status == #Stopped) {
          Runtime.trap("Lab already stopped");
        };
        if (instance.status == #Destroyed) {
          Runtime.trap("Lab already destroyed");
        };
        let updatedInstance : LabInstance = {
          userEmail = instance.userEmail;
          labId = instance.labId;
          status = #Stopped;
          startTime = instance.startTime;
          containerId = instance.containerId;
        };
        labInstances.add((userEmail, labId), updatedInstance);
        updatedInstance;
      };
    };
  };

  public shared func destroyLab(token : SessionToken, labId : Nat) : async () {
    let userEmail = validateToken(token);
    switch (labInstances.get((userEmail, labId))) {
      case (null) { Runtime.trap("Lab status not found") };
      case (?instance) {
        let updatedInstance : LabInstance = {
          userEmail = instance.userEmail;
          labId = instance.labId;
          status = #Destroyed;
          startTime = instance.startTime;
          containerId = instance.containerId;
        };
        labInstances.add((userEmail, labId), updatedInstance);
      };
    };
  };

  public query func getLabStatus(token : SessionToken, labId : Nat) : async LabInstance {
    let userEmail = validateToken(token);
    switch (labInstances.get((userEmail, labId))) {
      case (null) { Runtime.trap("Lab status not found") };
      case (?instance) {
        switch (instance.status) {
          case (#Running) {
            let now = Time.now();
            switch (instance.startTime) {
              case (?startTime) {
                if (now - startTime > 7200_000_000_000) {
                  {
                    userEmail = instance.userEmail;
                    labId = instance.labId;
                    status = #Stopped;
                    startTime = instance.startTime;
                    containerId = instance.containerId;
                  };
                } else {
                  instance;
                };
              };
              case (null) { instance };
            };
          };
          case (_) { instance };
        };
      };
    };
  };

  public query func isAdmin(email : Text) : async Bool {
    Text.equal(email, "admin@cyberrange.io");
  };

  public query func getAllMyLabStatuses(token : SessionToken) : async [LabInstance] {
    let userEmail = validateToken(token);
    let result = List.empty<LabInstance>();
    for (((email, _labId), instance) in labInstances.entries()) {
      if (Text.equal(email, userEmail)) {
        result.add(instance);
      };
    };
    result.toArray();
  };

  public query func getUserStats(token : SessionToken) : async UserStats {
    let userEmail = validateToken(token);
    var active = 0;
    var stopped = 0;
    var completed = 0;
    var total = 0;
    for (((email, _labId), instance) in labInstances.entries()) {
      if (Text.equal(email, userEmail)) {
        total += 1;
        switch (instance.status) {
          case (#Running) { active += 1 };
          case (#Stopped) { stopped += 1 };
          case (#Destroyed) { completed += 1 };
          case (#Idle) {};
        };
      };
    };
    {
      activeSessions = active;
      stoppedSessions = stopped;
      completedSessions = completed;
      totalLabsLaunched = total;
    };
  };

  // ---- ADMIN FUNCTIONS ----

  public query func adminGetAllUsers(token : SessionToken) : async [User] {
    validateAdminToken(token);
    users.values().toArray();
  };

  public shared func adminCreateUser(token : SessionToken, email : Text, password : Text) : async User {
    validateAdminToken(token);
    switch (users.get(email)) {
      case (?_) { Runtime.trap("User already exists") };
      case (null) {
        let newUser : User = { email; passwordHash = password };
        users.add(email, newUser);
        newUser;
      };
    };
  };

  public shared func adminUpdateUser(token : SessionToken, email : Text, newPassword : Text) : async User {
    validateAdminToken(token);
    switch (users.get(email)) {
      case (null) { Runtime.trap("User not found") };
      case (?user) {
        let updatedUser : User = { email = user.email; passwordHash = newPassword };
        users.add(email, updatedUser);
        updatedUser;
      };
    };
  };

  public shared func adminDeleteUser(token : SessionToken, email : Text) : async () {
    validateAdminToken(token);
    if (Text.equal(email, "admin@cyberrange.io")) {
      Runtime.trap("Cannot delete admin user");
    };
    switch (users.get(email)) {
      case (null) { Runtime.trap("User not found") };
      case (?_) { users.remove(email) };
    };
  };

  public query func adminGetAllLabInstances(token : SessionToken) : async [LabInstance] {
    validateAdminToken(token);
    labInstances.values().toArray();
  };

  public shared func adminLaunchLab(token : SessionToken, userEmail : Text, labId : Nat) : async LabInstance {
    validateAdminToken(token);
    switch (labs.get(labId)) {
      case (null) { Runtime.trap("Lab not found") };
      case (?_) {};
    };
    switch (users.get(userEmail)) {
      case (null) { Runtime.trap("User not found") };
      case (?_) {};
    };
    let containerId = "container_" # userEmail # "_" # labId.toText();
    let startTime = switch (labInstances.get((userEmail, labId))) {
      case (?existing) {
        switch (existing.status) {
          case (#Stopped) { existing.startTime };
          case (_) { ?Time.now() };
        };
      };
      case (null) { ?Time.now() };
    };
    let instance : LabInstance = {
      userEmail;
      labId;
      status = #Running;
      startTime;
      containerId = ?containerId;
    };
    labInstances.add((userEmail, labId), instance);
    instance;
  };

  public shared func adminStopLab(token : SessionToken, userEmail : Text, labId : Nat) : async LabInstance {
    validateAdminToken(token);
    switch (labInstances.get((userEmail, labId))) {
      case (null) { Runtime.trap("Lab instance not found") };
      case (?instance) {
        if (instance.status == #Stopped) { Runtime.trap("Lab already stopped") };
        if (instance.status == #Destroyed) { Runtime.trap("Lab already destroyed") };
        let updatedInstance : LabInstance = {
          userEmail = instance.userEmail;
          labId = instance.labId;
          status = #Stopped;
          startTime = instance.startTime;
          containerId = instance.containerId;
        };
        labInstances.add((userEmail, labId), updatedInstance);
        updatedInstance;
      };
    };
  };

  public shared func adminDestroyLab(token : SessionToken, userEmail : Text, labId : Nat) : async () {
    validateAdminToken(token);
    switch (labInstances.get((userEmail, labId))) {
      case (null) { Runtime.trap("Lab instance not found") };
      case (?instance) {
        let updatedInstance : LabInstance = {
          userEmail = instance.userEmail;
          labId = instance.labId;
          status = #Destroyed;
          startTime = instance.startTime;
          containerId = instance.containerId;
        };
        labInstances.add((userEmail, labId), updatedInstance);
      };
    };
  };

  public shared func adminCreateLab(token : SessionToken, name : Text, difficulty : LabDifficulty, description : Text, howToUse : Text, estimatedDuration : Nat, tools : [LabTool]) : async LabDetail {
    validateAdminToken(token);
    let labId = nextLabId;
    nextLabId += 1;
    let newLab : LabDetail = {
      id = labId;
      name;
      difficulty;
      description;
      tools = tools;
      howToUse;
      estimatedDuration;
    };
    labs.add(labId, newLab);
    newLab;
  };

  public shared func adminUpdateLab(token : SessionToken, labId : Nat, name : Text, difficulty : LabDifficulty, description : Text, howToUse : Text, estimatedDuration : Nat, tools : [LabTool]) : async LabDetail {
    validateAdminToken(token);
    switch (labs.get(labId)) {
      case (null) { Runtime.trap("Lab not found") };
      case (?lab) {
        let updatedLab : LabDetail = {
          id = lab.id;
          name;
          difficulty;
          description;
          tools = tools;
          howToUse;
          estimatedDuration;
        };
        labs.add(labId, updatedLab);
        updatedLab;
      };
    };
  };

  public shared func adminDeleteLab(token : SessionToken, labId : Nat) : async () {
    validateAdminToken(token);
    switch (labs.get(labId)) {
      case (null) { Runtime.trap("Lab not found") };
      case (?_) { labs.remove(labId) };
    };
  };
};
