import {
  BookOpen,
  FlaskConical,
  LayoutDashboard,
  LogOut,
  Shield,
  ShieldCheck,
  Terminal,
} from "lucide-react";
import { navigate } from "../App";

interface SidebarProps {
  activePage: "dashboard" | "lab" | "setup" | "admin";
}

export default function Sidebar({ activePage }: SidebarProps) {
  const email = localStorage.getItem("cr_email") || "operator@cyberrange.io";
  const role = localStorage.getItem("cr_role") || "user";
  const isAdmin = role === "admin";
  const initials = email.substring(0, 2).toUpperCase();

  function handleLogout() {
    localStorage.removeItem("cr_token");
    localStorage.removeItem("cr_email");
    localStorage.removeItem("cr_role");
    navigate({ name: "login" });
  }

  const navItems = [
    {
      id: "dashboard" as const,
      label: "Dashboard",
      icon: LayoutDashboard,
      action: () => navigate({ name: "dashboard" }),
      show: true,
    },
    {
      id: "lab" as const,
      label: "Labs",
      icon: FlaskConical,
      action: () => {
        navigate({ name: "dashboard" });
        setTimeout(() => {
          document
            .getElementById("available-labs-section")
            ?.scrollIntoView({ behavior: "smooth" });
        }, 100);
      },
      show: true,
    },
    {
      id: "admin" as const,
      label: "Admin Panel",
      icon: ShieldCheck,
      action: () => navigate({ name: "admin" }),
      show: isAdmin,
    },
    {
      id: "setup" as const,
      label: "Setup Guide",
      icon: BookOpen,
      action: () => navigate({ name: "setup" }),
      show: isAdmin,
    },
  ].filter((item) => item.show);

  return (
    <aside
      className="fixed left-0 top-0 h-full w-64 flex flex-col z-20"
      style={{
        background: "oklch(0.11 0.025 240)",
        borderRight: "1px solid oklch(0.28 0.055 240)",
      }}
    >
      <div
        className="px-5 py-6 border-b"
        style={{ borderColor: "oklch(0.28 0.055 240)" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{
              background: "oklch(0.19 0.045 235)",
              border: "1px solid oklch(0.80 0.13 200 / 0.5)",
            }}
          >
            <Shield
              className="w-4 h-4"
              style={{ color: "oklch(0.80 0.13 200)" }}
            />
          </div>
          <div>
            <div className="text-sm font-bold tracking-[0.12em] uppercase">
              <span style={{ color: "oklch(0.80 0.13 200)" }}>CYBER</span>
              <span className="text-foreground">|RANGE</span>
            </div>
            <div className="text-xs" style={{ color: "oklch(0.57 0.05 240)" }}>
              Training Platform
            </div>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const active =
            activePage === item.id ||
            (activePage === "lab" && item.id === "lab");
          return (
            <button
              type="button"
              key={item.id}
              data-ocid={`nav.${item.id}.link`}
              onClick={item.action}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left"
              style={{
                background: active
                  ? "oklch(0.80 0.13 200 / 0.12)"
                  : "transparent",
                color: active ? "oklch(0.80 0.13 200)" : "oklch(0.70 0.04 240)",
                borderLeft: active
                  ? "2px solid oklch(0.80 0.13 200)"
                  : "2px solid transparent",
              }}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div
        className="px-3 py-3 mx-3 mb-3 rounded-lg"
        style={{
          background: "oklch(0.085 0.022 240)",
          border: "1px solid oklch(0.28 0.055 240)",
        }}
      >
        <div className="flex items-center gap-2 mb-1">
          <Terminal
            className="w-3 h-3"
            style={{ color: "oklch(0.75 0.15 160)" }}
          />
          <span
            className="text-xs font-mono"
            style={{ color: "oklch(0.57 0.05 240)" }}
          >
            SYSTEM STATUS
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <div
            className="w-1.5 h-1.5 rounded-full animate-pulse"
            style={{ background: "oklch(0.75 0.15 160)" }}
          />
          <span
            className="text-xs font-mono"
            style={{ color: "oklch(0.75 0.15 160)" }}
          >
            OPERATIONAL
          </span>
        </div>
      </div>

      <div
        className="px-3 py-4 border-t"
        style={{ borderColor: "oklch(0.28 0.055 240)" }}
      >
        <div
          className="flex items-center gap-3 px-3 py-2 rounded-lg mb-2"
          style={{ background: "oklch(0.14 0.032 238)" }}
        >
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
            style={{
              background:
                "linear-gradient(135deg, oklch(0.80 0.13 200), oklch(0.75 0.15 160))",
              color: "oklch(0.085 0.022 240)",
            }}
          >
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <div
              className="text-xs font-medium truncate"
              style={{ color: "oklch(0.92 0.02 240)" }}
            >
              {email}
            </div>
            <div className="text-xs" style={{ color: "oklch(0.57 0.05 240)" }}>
              {isAdmin ? "Administrator" : "Operator"}
            </div>
          </div>
        </div>
        <button
          type="button"
          data-ocid="nav.logout.button"
          onClick={handleLogout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all"
          style={{ color: "oklch(0.57 0.05 240)" }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.background =
              "oklch(0.53 0.17 25 / 0.15)";
            (e.currentTarget as HTMLButtonElement).style.color =
              "oklch(0.75 0.12 25)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.background =
              "transparent";
            (e.currentTarget as HTMLButtonElement).style.color =
              "oklch(0.57 0.05 240)";
          }}
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
