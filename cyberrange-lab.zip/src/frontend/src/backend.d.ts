import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface LabDetail {
    id: bigint;
    tools: Array<LabTool>;
    difficulty: LabDifficulty;
    name: string;
    description: string;
    howToUse: string;
    estimatedDuration: bigint;
}
export interface LabInstance {
    startTime?: bigint;
    status: LabStatus;
    userEmail: string;
    containerId?: string;
    labId: bigint;
}
export interface LabSummary {
    id: bigint;
    difficulty: LabDifficulty;
    name: string;
    estimatedDuration: bigint;
}
export interface User {
    email: string;
    passwordHash: string;
}
export interface LabTool {
    name: string;
    description: string;
}
export type SessionToken = string;
export interface LoginResult {
    token: SessionToken;
    user: User;
}
export interface UserStats {
    completedSessions: bigint;
    stoppedSessions: bigint;
    totalLabsLaunched: bigint;
    activeSessions: bigint;
}
export enum LabDifficulty {
    Easy = "Easy",
    Hard = "Hard",
    Medium = "Medium",
    Extreme = "Extreme"
}
export enum LabStatus {
    Stopped = "Stopped",
    Idle = "Idle",
    Destroyed = "Destroyed",
    Running = "Running"
}
export interface backendInterface {
    adminCreateLab(token: SessionToken, name: string, difficulty: LabDifficulty, description: string, howToUse: string, estimatedDuration: bigint, tools: LabTool[]): Promise<LabDetail>;
    adminCreateUser(token: SessionToken, email: string, password: string): Promise<User>;
    adminDeleteLab(token: SessionToken, labId: bigint): Promise<void>;
    adminDeleteUser(token: SessionToken, email: string): Promise<void>;
    adminDestroyLab(token: SessionToken, userEmail: string, labId: bigint): Promise<void>;
    adminGetAllLabInstances(token: SessionToken): Promise<Array<LabInstance>>;
    adminGetAllUsers(token: SessionToken): Promise<Array<User>>;
    adminLaunchLab(token: SessionToken, userEmail: string, labId: bigint): Promise<LabInstance>;
    adminStopLab(token: SessionToken, userEmail: string, labId: bigint): Promise<LabInstance>;
    adminUpdateLab(token: SessionToken, labId: bigint, name: string, difficulty: LabDifficulty, description: string, howToUse: string, estimatedDuration: bigint, tools: LabTool[]): Promise<LabDetail>;
    adminUpdateUser(token: SessionToken, email: string, newPassword: string): Promise<User>;
    destroyLab(token: SessionToken, labId: bigint): Promise<void>;
    getAllMyLabStatuses(token: SessionToken): Promise<Array<LabInstance>>;
    getLabDetail(token: SessionToken, labId: bigint): Promise<LabDetail>;
    getLabStatus(token: SessionToken, labId: bigint): Promise<LabInstance>;
    getLabs(token: SessionToken): Promise<Array<LabSummary>>;
    getUserStats(token: SessionToken): Promise<UserStats>;
    isAdmin(email: string): Promise<boolean>;
    launchLab(token: SessionToken, labId: bigint): Promise<LabInstance>;
    login(email: string, password: string): Promise<LoginResult>;
    stopLab(token: SessionToken, labId: bigint): Promise<LabInstance>;
}
