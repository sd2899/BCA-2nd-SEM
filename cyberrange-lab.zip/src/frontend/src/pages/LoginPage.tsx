import { useQueryClient } from "@tanstack/react-query";
import { Loader2, Shield, Terminal } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";
import { navigate } from "../App";
import { useActor } from "../hooks/useActor";

export default function LoginPage() {
  const { actor, isFetching } = useActor();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!actor) return;
    setLoading(true);
    setError("");
    try {
      const result = await actor.login(email, password);
      localStorage.setItem("cr_token", result.token);
      localStorage.setItem("cr_email", result.user.email);
      // Store role: admin email gets admin privileges
      const isAdmin = result.user.email === "admin@cyberrange.io";
      localStorage.setItem("cr_role", isAdmin ? "admin" : "user");
      toast.success("Authentication successful");
      queryClient.clear();
      navigate({ name: "dashboard" });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Invalid credentials";
      setError(msg);
      toast.error("Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background cyber-grid flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full"
          style={{
            background:
              "radial-gradient(circle, oklch(0.80 0.13 200 / 0.07) 0%, transparent 70%)",
          }}
        />
      </div>
      <div
        className="absolute top-6 left-6 text-xs font-mono opacity-40 tracking-widest"
        style={{ color: "oklch(0.80 0.13 200)" }}
      >
        SYS://CYBERRANGE.IO
      </div>
      <div
        className="absolute bottom-6 right-6 text-xs font-mono opacity-30"
        style={{ color: "oklch(0.75 0.15 160)" }}
      >
        v2.4.1 SECURE
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md px-4"
      >
        <div
          className="rounded-2xl border p-8"
          style={{
            background: "oklch(0.14 0.032 238)",
            borderColor: "oklch(0.28 0.055 240)",
            boxShadow:
              "0 8px 48px oklch(0.085 0.022 240 / 0.8), inset 0 1px 0 oklch(0.80 0.13 200 / 0.1)",
          }}
        >
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-3">
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{
                  background: "oklch(0.19 0.045 235)",
                  border: "1px solid oklch(0.80 0.13 200 / 0.5)",
                }}
              >
                <Shield
                  className="w-5 h-5"
                  style={{ color: "oklch(0.80 0.13 200)" }}
                />
              </div>
            </div>
            <h1 className="text-2xl font-bold tracking-[0.15em] uppercase">
              <span style={{ color: "oklch(0.80 0.13 200)" }}>CYBER</span>
              <span className="text-foreground">|RANGE</span>
            </h1>
            <p
              className="text-sm mt-1"
              style={{ color: "oklch(0.57 0.05 240)" }}
            >
              Advanced Cybersecurity Training Platform
            </p>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <div
              className="flex-1 h-px"
              style={{ background: "oklch(0.28 0.055 240)" }}
            />
            <Terminal
              className="w-4 h-4"
              style={{ color: "oklch(0.57 0.05 240)" }}
            />
            <div
              className="flex-1 h-px"
              style={{ background: "oklch(0.28 0.055 240)" }}
            />
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label
                htmlFor="login-email"
                className="text-xs font-mono uppercase tracking-widest mb-2 block"
                style={{ color: "oklch(0.57 0.05 240)" }}
              >
                Email Address
              </label>
              <input
                data-ocid="login.input"
                id="login-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="operator@cyberrange.io"
                required
                className="w-full rounded-lg px-4 py-3 text-sm font-mono outline-none transition-all"
                style={{
                  background: "oklch(0.11 0.025 240)",
                  border: "1px solid oklch(0.28 0.055 240)",
                  color: "oklch(0.92 0.02 240)",
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = "oklch(0.80 0.13 200)";
                  e.target.style.boxShadow =
                    "0 0 0 3px oklch(0.80 0.13 200 / 0.12)";
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = "oklch(0.28 0.055 240)";
                  e.target.style.boxShadow = "none";
                }}
              />
            </div>
            <div>
              <label
                htmlFor="login-password"
                className="text-xs font-mono uppercase tracking-widest mb-2 block"
                style={{ color: "oklch(0.57 0.05 240)" }}
              >
                Password
              </label>
              <input
                data-ocid="login.password.input"
                id="login-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full rounded-lg px-4 py-3 text-sm font-mono outline-none transition-all"
                style={{
                  background: "oklch(0.11 0.025 240)",
                  border: "1px solid oklch(0.28 0.055 240)",
                  color: "oklch(0.92 0.02 240)",
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = "oklch(0.80 0.13 200)";
                  e.target.style.boxShadow =
                    "0 0 0 3px oklch(0.80 0.13 200 / 0.12)";
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = "oklch(0.28 0.055 240)";
                  e.target.style.boxShadow = "none";
                }}
              />
            </div>

            {error && (
              <div
                data-ocid="login.error_state"
                className="text-sm px-4 py-3 rounded-lg font-mono"
                style={{
                  background: "oklch(0.53 0.17 25 / 0.15)",
                  border: "1px solid oklch(0.53 0.17 25 / 0.4)",
                  color: "oklch(0.75 0.12 25)",
                }}
              >
                ⚠ {error}
              </div>
            )}

            <button
              data-ocid="login.submit_button"
              type="submit"
              disabled={loading || isFetching}
              className="w-full rounded-lg py-3 text-sm font-bold uppercase tracking-widest transition-all mt-2 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                background:
                  loading || isFetching
                    ? "oklch(0.19 0.045 235)"
                    : "linear-gradient(135deg, oklch(0.75 0.15 160), oklch(0.82 0.15 160))",
                color: "oklch(0.085 0.022 240)",
                boxShadow:
                  loading || isFetching
                    ? "none"
                    : "0 4px 20px oklch(0.75 0.15 160 / 0.4)",
              }}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Authenticating...
                </>
              ) : isFetching ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Connecting...
                </>
              ) : (
                "Sign In"
              )}
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
