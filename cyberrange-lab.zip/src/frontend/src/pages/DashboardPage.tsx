import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";
import { Activity, Bell, Clock, Cpu, Play, Search, Zap } from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { navigate } from "../App";
import type { LabInstance, LabSummary } from "../backend.d";
import { LabDifficulty, LabStatus } from "../backend.d";
import Sidebar from "../components/Sidebar";
import { useActor } from "../hooks/useActor";
import {
  useGetAllMyLabStatuses,
  useGetLabs,
  useGetUserStats,
} from "../hooks/useQueries";

const DIFF_META: Record<string, { label: string; color: string; bg: string }> =
  {
    [LabDifficulty.Easy]: {
      label: "Easy",
      color: "oklch(0.75 0.15 160)",
      bg: "oklch(0.75 0.15 160 / 0.15)",
    },
    [LabDifficulty.Medium]: {
      label: "Medium",
      color: "oklch(0.72 0.14 75)",
      bg: "oklch(0.72 0.14 75 / 0.15)",
    },
    [LabDifficulty.Hard]: {
      label: "Hard",
      color: "oklch(0.53 0.17 25)",
      bg: "oklch(0.53 0.17 25 / 0.15)",
    },
    [LabDifficulty.Extreme]: {
      label: "Extreme",
      color: "oklch(0.54 0.22 290)",
      bg: "oklch(0.54 0.22 290 / 0.15)",
    },
  };

const LAB_DESCS: Record<string, string> = {
  "1": "Master network intrusion techniques and defensive countermeasures in a live simulated environment.",
  "2": "Exploit web application vulnerabilities including XSS, SQL injection, and CSRF attacks.",
  "3": "Advanced reverse engineering and malware analysis with isolated sandbox environment.",
  "4": "Red team vs blue team simulation with real active defense mechanisms.",
  "5": "Cryptographic attack challenges covering modern encryption vulnerabilities.",
  "6": "Cloud infrastructure penetration testing on multi-tenant environments.",
};

function LabCard({
  lab,
  index,
  instance,
}: {
  lab: LabSummary;
  index: number;
  instance?: LabInstance;
}) {
  const meta = DIFF_META[lab.difficulty] || DIFF_META[LabDifficulty.Easy];
  const desc =
    LAB_DESCS[lab.id.toString()] ||
    "Explore this cybersecurity challenge in a sandboxed environment.";

  const isRunning = instance?.status === LabStatus.Running;
  const isStopped = instance?.status === LabStatus.Stopped;
  const hasActiveSession = isRunning || isStopped;

  const statusColor = isRunning
    ? "oklch(0.75 0.15 160)"
    : isStopped
      ? "oklch(0.72 0.14 75)"
      : null;
  const statusBg = isRunning
    ? "oklch(0.75 0.15 160 / 0.15)"
    : isStopped
      ? "oklch(0.72 0.14 75 / 0.15)"
      : null;
  const statusLabel = isRunning ? "RUNNING" : isStopped ? "STOPPED" : null;

  function handleLabClick(e: React.MouseEvent) {
    e.stopPropagation();
    navigate({ name: "lab", labId: lab.id });
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        delay: index * 0.08,
        duration: 0.4,
        ease: [0.22, 1, 0.36, 1],
      }}
      data-ocid={`labs.item.${index + 1}`}
      className="rounded-2xl p-5 flex flex-col gap-4 transition-all"
      style={{
        background: "oklch(0.14 0.032 238)",
        border: `1px solid ${
          isRunning
            ? "oklch(0.75 0.15 160 / 0.4)"
            : isStopped
              ? "oklch(0.72 0.14 75 / 0.4)"
              : "oklch(0.28 0.055 240)"
        }`,
        position: "relative",
      }}
    >
      <div className="flex items-start justify-between">
        <span
          className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
          style={{ color: meta.color, background: meta.bg }}
        >
          {meta.label}
        </span>
        <div className="flex items-center gap-2">
          {hasActiveSession && statusColor && statusBg && statusLabel && (
            <span
              className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md flex items-center gap-1"
              style={{ color: statusColor, background: statusBg }}
            >
              {isRunning && (
                <span
                  className="w-1.5 h-1.5 rounded-full animate-pulse inline-block"
                  style={{ background: statusColor }}
                />
              )}
              {statusLabel}
            </span>
          )}
          <div
            className="flex items-center gap-1 text-xs"
            style={{ color: "oklch(0.57 0.05 240)" }}
          >
            <Cpu className="w-3 h-3" />
            <span>{lab.id ? Number(lab.id) + 2 : 3} tools</span>
          </div>
        </div>
      </div>
      <div>
        <h3
          className="font-semibold text-base mb-1"
          style={{ color: "oklch(0.92 0.02 240)" }}
        >
          {lab.name}
        </h3>
        <p
          className="text-sm leading-relaxed"
          style={{ color: "oklch(0.57 0.05 240)" }}
        >
          {desc}
        </p>
      </div>
      <div
        className="flex items-center gap-1 text-xs"
        style={{ color: "oklch(0.57 0.05 240)" }}
      >
        <Clock className="w-3 h-3" />
        <span>{Number(lab.estimatedDuration)}h estimated</span>
      </div>
      <button
        type="button"
        data-ocid={`labs.start.button.${index + 1}`}
        onClick={handleLabClick}
        className="w-full py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
        style={{
          position: "relative",
          zIndex: 2,
          ...(isRunning
            ? {
                background:
                  "linear-gradient(135deg, oklch(0.75 0.15 160), oklch(0.82 0.15 160))",
                color: "oklch(0.085 0.022 240)",
                boxShadow: "0 4px 16px oklch(0.75 0.15 160 / 0.3)",
              }
            : isStopped
              ? {
                  background:
                    "linear-gradient(135deg, oklch(0.72 0.14 75), oklch(0.78 0.14 75))",
                  color: "oklch(0.085 0.022 240)",
                  boxShadow: "0 4px 16px oklch(0.72 0.14 75 / 0.3)",
                }
              : {
                  background:
                    "linear-gradient(135deg, oklch(0.80 0.13 200), oklch(0.75 0.15 160))",
                  color: "oklch(0.085 0.022 240)",
                  boxShadow: "0 4px 16px oklch(0.80 0.13 200 / 0.3)",
                }),
        }}
      >
        <Play className="w-3.5 h-3.5" />
        {isRunning ? "OPEN LAB" : isStopped ? "RESUME LAB" : "START LAB"}
      </button>
    </motion.div>
  );
}

export default function DashboardPage() {
  const { actor, isFetching } = useActor();
  const { data: labs, isLoading } = useGetLabs();
  const { data: myLabStatuses } = useGetAllMyLabStatuses();
  const { data: userStats } = useGetUserStats();
  const qc = useQueryClient();
  const email = localStorage.getItem("cr_email") || "op";
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (actor && !isFetching) {
      qc.invalidateQueries({ queryKey: ["my-lab-statuses"] });
      qc.invalidateQueries({ queryKey: ["user-stats"] });
    }
  }, [actor, isFetching, qc]);

  // Build a map of labId -> LabInstance for quick lookup
  const labStatusMap = new Map<string, LabInstance>();
  for (const inst of myLabStatuses || []) {
    if (
      inst.status === LabStatus.Running ||
      inst.status === LabStatus.Stopped
    ) {
      labStatusMap.set(inst.labId.toString(), inst);
    }
  }

  // Derive active sessions count from real data; fall back to userStats
  const activeSessions =
    myLabStatuses != null
      ? myLabStatuses.filter((i) => i.status === LabStatus.Running).length
      : Number(userStats?.activeSessions || 0n);

  const completedSessions = Number(userStats?.completedSessions || 0n);
  const availableLabs = labs?.length || 0;

  const activeOrStoppedLabs = (myLabStatuses || []).filter(
    (inst) =>
      inst.status === LabStatus.Running || inst.status === LabStatus.Stopped,
  );

  const filteredLabs = (labs || []).filter((lab) =>
    lab.name.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div
      className="flex min-h-screen"
      style={{ background: "oklch(0.085 0.022 240)" }}
    >
      <Sidebar activePage="dashboard" />
      <main className="flex-1 ml-64 flex flex-col min-h-screen">
        <header
          className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
          style={{
            background: "oklch(0.085 0.022 240 / 0.95)",
            borderBottom: "1px solid oklch(0.28 0.055 240)",
            backdropFilter: "blur(8px)",
          }}
        >
          <div>
            <h1
              className="text-xl font-bold"
              style={{ color: "oklch(0.92 0.02 240)" }}
            >
              Labs Dashboard
            </h1>
            <p className="text-xs" style={{ color: "oklch(0.57 0.05 240)" }}>
              Active Labs &amp; Available Scenarios
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div
              className="flex items-center gap-2 px-4 py-2 rounded-lg"
              style={{
                background: "oklch(0.14 0.032 238)",
                border: "1px solid oklch(0.28 0.055 240)",
              }}
            >
              <Search
                className="w-4 h-4"
                style={{ color: "oklch(0.57 0.05 240)" }}
              />
              <input
                data-ocid="dashboard.search_input"
                placeholder="Search labs..."
                className="bg-transparent text-sm outline-none w-40"
                style={{ color: "oklch(0.92 0.02 240)" }}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <button
              type="button"
              className="w-9 h-9 rounded-lg flex items-center justify-center"
              style={{
                background: "oklch(0.14 0.032 238)",
                border: "1px solid oklch(0.28 0.055 240)",
              }}
            >
              <Bell
                className="w-4 h-4"
                style={{ color: "oklch(0.57 0.05 240)" }}
              />
            </button>
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold"
              style={{
                background:
                  "linear-gradient(135deg, oklch(0.80 0.13 200), oklch(0.75 0.15 160))",
                color: "oklch(0.085 0.022 240)",
              }}
            >
              {email.substring(0, 2).toUpperCase()}
            </div>
          </div>
        </header>

        <div className="flex-1 px-8 py-6 space-y-8">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-3 gap-4"
          >
            {[
              {
                label: "Available Labs",
                value: availableLabs,
                icon: Zap,
                color: "oklch(0.80 0.13 200)",
              },
              {
                label: "Active Sessions",
                value: activeSessions,
                icon: Activity,
                color: "oklch(0.75 0.15 160)",
              },
              {
                label: "Completed Sessions",
                value: completedSessions,
                icon: Play,
                color: "oklch(0.54 0.22 290)",
              },
            ].map((stat) => (
              <div
                key={stat.label}
                className="rounded-xl p-4"
                style={{
                  background: "oklch(0.14 0.032 238)",
                  border: "1px solid oklch(0.28 0.055 240)",
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span
                    className="text-xs"
                    style={{ color: "oklch(0.57 0.05 240)" }}
                  >
                    {stat.label}
                  </span>
                  <stat.icon
                    className="w-4 h-4"
                    style={{ color: stat.color }}
                  />
                </div>
                <div
                  className="text-2xl font-bold"
                  style={{ color: stat.color }}
                >
                  {stat.value}
                </div>
              </div>
            ))}
          </motion.div>

          <section id="available-labs-section">
            <div className="flex items-center justify-between mb-4">
              <h2
                className="text-base font-semibold"
                style={{ color: "oklch(0.92 0.02 240)" }}
              >
                Available Labs
              </h2>
              <div
                className="text-xs font-mono"
                style={{ color: "oklch(0.57 0.05 240)" }}
              >
                {filteredLabs.length} scenarios{search ? " found" : " loaded"}
              </div>
            </div>
            {isLoading ? (
              <div
                data-ocid="labs.loading_state"
                className="grid grid-cols-3 gap-4"
              >
                {[1, 2, 3].map((i) => (
                  <Skeleton
                    key={i}
                    className="h-56 rounded-2xl"
                    style={{ background: "oklch(0.14 0.032 238)" }}
                  />
                ))}
              </div>
            ) : filteredLabs.length > 0 ? (
              <div className="grid grid-cols-3 gap-4">
                {filteredLabs.map((lab, i) => (
                  <LabCard
                    key={lab.id.toString()}
                    lab={lab}
                    index={i}
                    instance={labStatusMap.get(lab.id.toString())}
                  />
                ))}
              </div>
            ) : (
              <div
                data-ocid="labs.empty_state"
                className="text-center py-16 rounded-2xl"
                style={{
                  background: "oklch(0.14 0.032 238)",
                  border: "1px solid oklch(0.28 0.055 240)",
                }}
              >
                <Zap
                  className="w-10 h-10 mx-auto mb-3"
                  style={{ color: "oklch(0.57 0.05 240)" }}
                />
                <p style={{ color: "oklch(0.57 0.05 240)" }}>
                  {search
                    ? `No labs matching "${search}"`
                    : "No labs available. Initializing..."}
                </p>
              </div>
            )}
          </section>

          <div
            className="rounded-2xl p-5"
            style={{
              background: "oklch(0.14 0.032 238)",
              border: "1px solid oklch(0.28 0.055 240)",
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3
                className="font-semibold text-sm"
                style={{ color: "oklch(0.92 0.02 240)" }}
              >
                My Active Labs
              </h3>
              <div className="flex items-center gap-1.5">
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: "oklch(0.75 0.15 160)" }}
                />
                <span
                  className="text-xs"
                  style={{ color: "oklch(0.57 0.05 240)" }}
                >
                  Live
                </span>
              </div>
            </div>
            {activeOrStoppedLabs.length > 0 ? (
              <div className="space-y-2">
                {activeOrStoppedLabs.map((inst, i) => {
                  const labName =
                    labs?.find((l) => l.id === inst.labId)?.name ||
                    `Lab #${inst.labId}`;
                  const isRunning = inst.status === LabStatus.Running;
                  const containerId = inst.containerId || "—";
                  const displayId =
                    containerId.length > 20
                      ? `${containerId.slice(0, 20)}...`
                      : containerId;
                  return (
                    <div
                      key={`${inst.labId}-${i}`}
                      data-ocid={`active_labs.item.${i + 1}`}
                      className="flex items-center justify-between px-4 py-3 rounded-xl"
                      style={{
                        background: "oklch(0.11 0.025 240)",
                        border: "1px solid oklch(0.28 0.055 240)",
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-2 h-2 rounded-full ${isRunning ? "animate-pulse" : ""}`}
                          style={{
                            background: isRunning
                              ? "oklch(0.75 0.15 160)"
                              : "oklch(0.72 0.14 75)",
                          }}
                        />
                        <div>
                          <div
                            className="text-sm font-semibold"
                            style={{ color: "oklch(0.92 0.02 240)" }}
                          >
                            {labName}
                          </div>
                          <div
                            className="text-xs font-mono mt-0.5"
                            style={{ color: "oklch(0.57 0.05 240)" }}
                          >
                            {displayId}
                          </div>
                        </div>
                      </div>
                      <span
                        className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                        style={{
                          color: isRunning
                            ? "oklch(0.75 0.15 160)"
                            : "oklch(0.72 0.14 75)",
                          background: isRunning
                            ? "oklch(0.75 0.15 160 / 0.15)"
                            : "oklch(0.72 0.14 75 / 0.15)",
                        }}
                      >
                        {inst.status}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div
                data-ocid="active_labs.empty_state"
                className="text-center py-8"
              >
                <Activity
                  className="w-8 h-8 mx-auto mb-2"
                  style={{ color: "oklch(0.28 0.055 240)" }}
                />
                <p
                  className="text-sm"
                  style={{ color: "oklch(0.57 0.05 240)" }}
                >
                  No active lab sessions
                </p>
                <p
                  className="text-xs mt-1"
                  style={{ color: "oklch(0.40 0.04 240)" }}
                >
                  Launch a lab to start training
                </p>
              </div>
            )}
          </div>
        </div>

        <footer
          className="px-8 py-4 border-t text-center"
          style={{ borderColor: "oklch(0.28 0.055 240)" }}
        >
          <p className="text-xs" style={{ color: "oklch(0.40 0.04 240)" }}>
            © {new Date().getFullYear()}. Built with ❤ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noreferrer"
              style={{ color: "oklch(0.80 0.13 200)" }}
            >
              caffeine.ai
            </a>{" "}
            · SYSTEM OPERATIONAL
          </p>
        </footer>
      </main>
    </div>
  );
}
