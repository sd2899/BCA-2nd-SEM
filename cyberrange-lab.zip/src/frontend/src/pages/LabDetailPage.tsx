import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CheckCircle,
  ChevronRight,
  ClipboardCopy,
  Clock,
  Cpu,
  ExternalLink,
  Info,
  Loader2,
  Monitor,
  PauseCircle,
  Play,
  Shield,
  Square,
  Terminal,
  Trash2,
  Zap,
} from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { navigate } from "../App";
import { LabDifficulty, LabStatus } from "../backend.d";
import type { LabTool } from "../backend.d";
import Sidebar from "../components/Sidebar";
import {
  useDestroyLab,
  useGetLabDetail,
  useGetLabStatus,
  useGetLabs,
  useLaunchLab,
  useStopLab,
} from "../hooks/useQueries";

const LAB_DURATION_SECS = 7200;

const DIFF_META: Record<string, { label: string; color: string; bg: string }> =
  {
    [LabDifficulty.Easy]: {
      label: "Easy",
      color: "oklch(0.75 0.15 160)",
      bg: "oklch(0.75 0.15 160 / 0.15)",
    },
    [LabDifficulty.Medium]: {
      label: "Medium",
      color: "oklch(0.72 0.14 75)",
      bg: "oklch(0.72 0.14 75 / 0.15)",
    },
    [LabDifficulty.Hard]: {
      label: "Hard",
      color: "oklch(0.53 0.17 25)",
      bg: "oklch(0.53 0.17 25 / 0.15)",
    },
    [LabDifficulty.Extreme]: {
      label: "Extreme",
      color: "oklch(0.54 0.22 290)",
      bg: "oklch(0.54 0.22 290 / 0.15)",
    },
  };

function formatTime(secs: number) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

interface Props {
  labId: bigint;
}

function CopyButton({ text }: { text: string }) {
  function handleCopy() {
    navigator.clipboard.writeText(text).then(() => {
      toast.success("Copied!");
    });
  }
  return (
    <button
      type="button"
      onClick={handleCopy}
      className="ml-2 p-1.5 rounded-md transition-all hover:scale-110"
      style={{
        background: "oklch(0.80 0.13 200 / 0.15)",
        color: "oklch(0.80 0.13 200)",
      }}
      title="Copy to clipboard"
    >
      <ClipboardCopy className="w-3.5 h-3.5" />
    </button>
  );
}

function CommandLine({ label, command }: { label: string; command: string }) {
  return (
    <div className="mb-3">
      <div
        className="text-xs uppercase tracking-wider mb-1"
        style={{ color: "oklch(0.57 0.05 240)" }}
      >
        {label}
      </div>
      <div
        className="flex items-center gap-2 rounded-lg px-3 py-2"
        style={{
          background: "oklch(0.085 0.022 240)",
          border: "1px solid oklch(0.28 0.055 240)",
        }}
      >
        <span
          className="font-mono text-xs flex-1 select-all"
          style={{ color: "oklch(0.80 0.13 200)" }}
        >
          {command}
        </span>
        <CopyButton text={command} />
      </div>
    </div>
  );
}

export default function LabDetailPage({ labId }: Props) {
  const { data: allLabs } = useGetLabs();
  const { data: lab, isLoading } = useGetLabDetail(labId);
  const [pollEnabled, setPollEnabled] = useState(true);
  const { data: labStatus, refetch: refetchStatus } = useGetLabStatus(
    labId,
    pollEnabled,
  );
  const launchMut = useLaunchLab();
  const stopMut = useStopLab();
  const destroyMut = useDestroyLab();
  const [timeLeft, setTimeLeft] = useState(LAB_DURATION_SECS);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const status = labStatus?.status;
  const isLabRunning = status === LabStatus.Running;
  const isLabStopped = status === LabStatus.Stopped;

  // biome-ignore lint/correctness/useExhaustiveDependencies: timer logic intentionally depends only on isLabRunning
  useEffect(() => {
    if (isLabRunning) {
      setPollEnabled(true);
      const startNs = labStatus?.startTime;
      if (startNs) {
        const startMs = Number(startNs) / 1_000_000;
        const elapsed = Math.floor((Date.now() - startMs) / 1000);
        setTimeLeft(Math.max(0, LAB_DURATION_SECS - elapsed));
      }
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            destroyMut.mutate(labId);
            toast.warning("Lab time expired — container destroyed");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (isLabStopped) {
      // When stopped, compute remaining time from startTime if available
      const startNs = labStatus?.startTime;
      if (startNs) {
        const startMs = Number(startNs) / 1_000_000;
        const elapsed = Math.floor((Date.now() - startMs) / 1000);
        setTimeLeft(Math.max(0, LAB_DURATION_SECS - elapsed));
      }
      clearInterval(timerRef.current!);
    } else {
      clearInterval(timerRef.current!);
    }
    return () => clearInterval(timerRef.current!);
  }, [isLabRunning, isLabStopped]);

  async function handleLaunch() {
    try {
      await launchMut.mutateAsync(labId);
      toast.success("Lab launched! Connect via SSH — see access panel below.");
      refetchStatus();
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed to launch");
    }
  }

  async function handleStop() {
    try {
      await stopMut.mutateAsync(labId);
      toast.success("Lab stopped");
      refetchStatus();
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed to stop");
    }
  }

  async function handleDestroy() {
    try {
      await destroyMut.mutateAsync(labId);
      toast.success("Lab destroyed — container removed");
      setTimeLeft(LAB_DURATION_SECS);
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : "Failed to destroy");
    }
  }

  const progressPct =
    ((LAB_DURATION_SECS - timeLeft) / LAB_DURATION_SECS) * 100;
  const diffMeta = lab
    ? DIFF_META[lab.difficulty] || DIFF_META[LabDifficulty.Easy]
    : null;

  const novncUrl = (labStatus as any)?.port
    ? `http://localhost:${(labStatus as any).port}`
    : null;
  const kaliPassword = (labStatus as any)?.kaliPassword ?? null;

  const hasContainer = !!(
    labStatus?.containerId &&
    (isLabRunning || isLabStopped)
  );

  return (
    <div
      className="flex min-h-screen"
      style={{ background: "oklch(0.085 0.022 240)" }}
    >
      <Sidebar activePage="lab" />
      <main className="flex-1 ml-64 flex flex-col">
        <header
          className="sticky top-0 z-10 flex items-center px-8 py-4 gap-3"
          style={{
            background: "oklch(0.085 0.022 240 / 0.95)",
            borderBottom: "1px solid oklch(0.28 0.055 240)",
            backdropFilter: "blur(8px)",
          }}
        >
          <button
            type="button"
            onClick={() => navigate({ name: "dashboard" })}
            className="text-xs font-mono flex items-center gap-1 transition-colors"
            style={{ color: "oklch(0.57 0.05 240)" }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.color =
                "oklch(0.80 0.13 200)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.color =
                "oklch(0.57 0.05 240)";
            }}
          >
            Dashboard <ChevronRight className="w-3 h-3" />
          </button>
          <span
            className="text-xs font-mono"
            style={{ color: "oklch(0.80 0.13 200)" }}
          >
            {lab?.name || "Lab Detail"}
          </span>
        </header>

        <div className="flex flex-1">
          {/* Left lab list */}
          <aside
            className="w-60 shrink-0 border-r p-4"
            style={{ borderColor: "oklch(0.28 0.055 240)" }}
          >
            <div
              className="text-xs font-mono uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.57 0.05 240)" }}
            >
              All Scenarios
            </div>
            <div className="space-y-1">
              {allLabs?.map((l, i) => (
                <button
                  type="button"
                  key={l.id.toString()}
                  data-ocid={`lab_list.item.${i + 1}`}
                  onClick={() => navigate({ name: "lab", labId: l.id })}
                  className="w-full text-left px-3 py-2.5 rounded-lg text-sm transition-all"
                  style={{
                    background:
                      l.id === labId
                        ? "oklch(0.80 0.13 200 / 0.12)"
                        : "transparent",
                    color:
                      l.id === labId
                        ? "oklch(0.80 0.13 200)"
                        : "oklch(0.70 0.04 240)",
                    borderLeft:
                      l.id === labId
                        ? "2px solid oklch(0.80 0.13 200)"
                        : "2px solid transparent",
                  }}
                >
                  {l.name}
                </button>
              ))}
            </div>
            {lab && (
              <button
                type="button"
                data-ocid="lab_list.start.button"
                onClick={handleLaunch}
                disabled={isLabRunning || launchMut.isPending}
                className="w-full mt-6 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all disabled:opacity-40"
                style={{
                  background:
                    "linear-gradient(135deg, oklch(0.75 0.15 160), oklch(0.82 0.15 160))",
                  color: "oklch(0.085 0.022 240)",
                  boxShadow: isLabRunning
                    ? "none"
                    : "0 4px 16px oklch(0.75 0.15 160 / 0.3)",
                }}
              >
                <Play className="w-3.5 h-3.5" /> START LAB
              </button>
            )}
          </aside>

          {/* Right detail */}
          <div className="flex-1 p-6 overflow-y-auto">
            {isLoading ? (
              <div data-ocid="lab_detail.loading_state" className="space-y-4">
                <Skeleton
                  className="h-8 w-64"
                  style={{ background: "oklch(0.14 0.032 238)" }}
                />
                <Skeleton
                  className="h-24 w-full"
                  style={{ background: "oklch(0.14 0.032 238)" }}
                />
              </div>
            ) : lab ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="space-y-5"
              >
                {/* Header */}
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    {diffMeta && (
                      <span
                        className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                        style={{
                          color: diffMeta.color,
                          background: diffMeta.bg,
                        }}
                      >
                        {lab.difficulty}
                      </span>
                    )}
                    {isLabRunning && (
                      <span
                        className="text-xs font-mono flex items-center gap-1"
                        style={{ color: "oklch(0.75 0.15 160)" }}
                      >
                        <span
                          className="w-1.5 h-1.5 rounded-full animate-pulse inline-block"
                          style={{ background: "oklch(0.75 0.15 160)" }}
                        />{" "}
                        RUNNING
                      </span>
                    )}
                    {isLabStopped && (
                      <span
                        className="text-xs font-mono"
                        style={{ color: "oklch(0.72 0.14 75)" }}
                      >
                        STOPPED
                      </span>
                    )}
                    {status === LabStatus.Destroyed && (
                      <span
                        className="text-xs font-mono"
                        style={{ color: "oklch(0.53 0.17 25)" }}
                      >
                        DESTROYED
                      </span>
                    )}
                  </div>
                  <h1
                    className="text-2xl font-bold"
                    style={{ color: "oklch(0.92 0.02 240)" }}
                  >
                    {lab.name}
                  </h1>
                  <p
                    className="text-sm mt-2 leading-relaxed"
                    style={{ color: "oklch(0.57 0.05 240)" }}
                  >
                    {lab.description}
                  </p>
                  <div className="flex items-center gap-6 mt-4">
                    {[
                      {
                        icon: Shield,
                        label: "Difficulty",
                        value: lab.difficulty,
                      },
                      {
                        icon: Clock,
                        label: "Duration",
                        value: `${Number(lab.estimatedDuration)}h`,
                      },
                      {
                        icon: Cpu,
                        label: "Tools",
                        value: String(lab.tools.length),
                      },
                    ].map((item) => (
                      <div
                        key={item.label}
                        className="flex items-center gap-2 text-sm"
                      >
                        <item.icon
                          className="w-4 h-4"
                          style={{ color: "oklch(0.80 0.13 200)" }}
                        />
                        <span style={{ color: "oklch(0.57 0.05 240)" }}>
                          {item.label}:
                        </span>
                        <span
                          className="font-medium"
                          style={{ color: "oklch(0.92 0.02 240)" }}
                        >
                          {item.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Timer — Running */}
                {isLabRunning && (
                  <div
                    className="rounded-xl p-4"
                    style={{
                      background: "oklch(0.14 0.032 238)",
                      border: "1px solid oklch(0.28 0.055 240)",
                    }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Clock
                          className="w-4 h-4"
                          style={{ color: "oklch(0.80 0.13 200)" }}
                        />
                        <span
                          className="text-sm font-medium"
                          style={{ color: "oklch(0.92 0.02 240)" }}
                        >
                          Session Timer
                        </span>
                      </div>
                      <span
                        data-ocid="lab.timer"
                        className="font-mono text-lg font-bold"
                        style={{
                          color:
                            timeLeft < 600
                              ? "oklch(0.53 0.17 25)"
                              : "oklch(0.80 0.13 200)",
                        }}
                      >
                        {formatTime(timeLeft)}
                      </span>
                    </div>
                    <Progress value={progressPct} className="h-1.5" />
                    <p
                      className="text-xs mt-2"
                      style={{ color: "oklch(0.57 0.05 240)" }}
                    >
                      Lab auto-destroys after 2 hours
                    </p>
                  </div>
                )}

                {/* Timer — Paused (Stopped) */}
                {isLabStopped && (
                  <div
                    className="rounded-xl p-4 flex items-center justify-between"
                    style={{
                      background: "oklch(0.14 0.032 238)",
                      border: "1px solid oklch(0.72 0.14 75 / 0.4)",
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <PauseCircle
                        className="w-4 h-4"
                        style={{ color: "oklch(0.72 0.14 75)" }}
                      />
                      <span
                        className="text-sm font-medium"
                        style={{ color: "oklch(0.72 0.14 75)" }}
                      >
                        Session paused
                      </span>
                    </div>
                    <span
                      data-ocid="lab.timer_paused"
                      className="font-mono text-lg font-bold"
                      style={{ color: "oklch(0.72 0.14 75)" }}
                    >
                      {formatTime(timeLeft)} remaining
                    </span>
                  </div>
                )}

                {/* Kali Desktop Access Panel */}
                {hasContainer && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    data-ocid="lab.container_access.panel"
                    className="rounded-xl p-5"
                    style={{
                      background: "oklch(0.14 0.032 238)",
                      border: "2px solid oklch(0.80 0.13 200 / 0.4)",
                      boxShadow: "0 0 24px oklch(0.80 0.13 200 / 0.08)",
                    }}
                  >
                    <div className="flex items-center gap-2 mb-4">
                      <div
                        className="w-7 h-7 rounded-lg flex items-center justify-center"
                        style={{ background: "oklch(0.80 0.13 200 / 0.18)" }}
                      >
                        <Monitor
                          className="w-4 h-4"
                          style={{ color: "oklch(0.80 0.13 200)" }}
                        />
                      </div>
                      <h3
                        className="text-sm font-bold uppercase tracking-wider"
                        style={{ color: "oklch(0.80 0.13 200)" }}
                      >
                        Kali Desktop Access
                      </h3>
                      {isLabStopped && (
                        <span
                          className="ml-auto text-xs px-2 py-0.5 rounded-full font-mono"
                          style={{
                            background: "oklch(0.72 0.14 75 / 0.15)",
                            color: "oklch(0.72 0.14 75)",
                          }}
                        >
                          Container paused — relaunch to reconnect
                        </span>
                      )}
                    </div>

                    {/* Open Desktop Button */}
                    {novncUrl && isLabRunning && (
                      <a
                        href={novncUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 w-full rounded-lg px-4 py-3 mb-4 font-semibold text-sm transition-all hover:opacity-90"
                        style={{
                          background: "oklch(0.55 0.18 200)",
                          color: "oklch(0.98 0.01 200)",
                        }}
                      >
                        <ExternalLink className="w-4 h-4" />
                        Open Kali Desktop in Browser
                      </a>
                    )}

                    <CommandLine
                      label="noVNC URL"
                      command={novncUrl ?? "http://localhost:<port>"}
                    />
                    <CommandLine
                      label="Desktop Password"
                      command={kaliPassword ?? "••••••••••••"}
                    />

                    <div
                      className="flex items-start gap-2 rounded-lg px-3 py-2 mt-1"
                      style={{
                        background: "oklch(0.80 0.13 200 / 0.07)",
                        border: "1px solid oklch(0.80 0.13 200 / 0.2)",
                      }}
                    >
                      <Info
                        className="w-3.5 h-3.5 mt-0.5 shrink-0"
                        style={{ color: "oklch(0.80 0.13 200)" }}
                      />
                      <p
                        className="text-xs leading-relaxed"
                        style={{ color: "oklch(0.70 0.06 220)" }}
                      >
                        The desktop may take 30–60 seconds to be ready after
                        launch. If the page shows "connecting", wait a moment
                        and refresh. Make sure the backend server is running
                        locally.{" "}
                        <button
                          type="button"
                          onClick={() => navigate({ name: "setup" })}
                          className="underline underline-offset-2 hover:opacity-80"
                          style={{ color: "oklch(0.80 0.13 200)" }}
                        >
                          See Setup page.
                        </button>
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Tools */}
                <div>
                  <h2
                    className="text-sm font-semibold uppercase tracking-wider mb-3 flex items-center gap-2"
                    style={{ color: "oklch(0.57 0.05 240)" }}
                  >
                    <Cpu className="w-4 h-4" /> Installed Tools
                  </h2>
                  <div className="grid grid-cols-2 gap-3">
                    {lab.tools.map((tool: LabTool, i: number) => (
                      <div
                        key={tool.name}
                        data-ocid={`tools.item.${i + 1}`}
                        className="rounded-xl p-4"
                        style={{
                          background: "oklch(0.14 0.032 238)",
                          border: "1px solid oklch(0.28 0.055 240)",
                        }}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div
                            className="w-6 h-6 rounded-md flex items-center justify-center"
                            style={{
                              background: "oklch(0.80 0.13 200 / 0.15)",
                            }}
                          >
                            <Terminal
                              className="w-3 h-3"
                              style={{ color: "oklch(0.80 0.13 200)" }}
                            />
                          </div>
                          <span
                            className="text-sm font-semibold"
                            style={{ color: "oklch(0.92 0.02 240)" }}
                          >
                            {tool.name}
                          </span>
                        </div>
                        <p
                          className="text-xs"
                          style={{ color: "oklch(0.57 0.05 240)" }}
                        >
                          {tool.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* How-To Guide */}
                <div>
                  <h2
                    className="text-sm font-semibold uppercase tracking-wider mb-3 flex items-center gap-2"
                    style={{ color: "oklch(0.57 0.05 240)" }}
                  >
                    <Info className="w-4 h-4" /> How-To Guide
                  </h2>
                  <div
                    className="rounded-xl p-4 font-mono text-xs leading-relaxed overflow-x-auto"
                    style={{
                      background: "oklch(0.085 0.022 240)",
                      border: "1px solid oklch(0.28 0.055 240)",
                      color: "oklch(0.75 0.15 160)",
                    }}
                  >
                    <div
                      className="flex items-center gap-2 mb-3 pb-2"
                      style={{
                        borderBottom: "1px solid oklch(0.28 0.055 240)",
                      }}
                    >
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ background: "oklch(0.53 0.17 25)" }}
                      />
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ background: "oklch(0.72 0.14 75)" }}
                      />
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ background: "oklch(0.75 0.15 160)" }}
                      />
                      <span
                        className="ml-2 text-xs"
                        style={{ color: "oklch(0.40 0.04 240)" }}
                      >
                        operator@cyberrange:~$
                      </span>
                    </div>
                    <pre className="whitespace-pre-wrap">{lab.howToUse}</pre>
                  </div>
                </div>

                {/* Lab Controls */}
                <div>
                  <h2
                    className="text-sm font-semibold uppercase tracking-wider mb-3 flex items-center gap-2"
                    style={{ color: "oklch(0.57 0.05 240)" }}
                  >
                    <Zap className="w-4 h-4" /> Lab Controls
                  </h2>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      data-ocid="lab.launch_lab.button"
                      onClick={handleLaunch}
                      disabled={isLabRunning || launchMut.isPending}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                      style={{
                        background:
                          "linear-gradient(135deg, oklch(0.75 0.15 160), oklch(0.82 0.15 160))",
                        color: "oklch(0.085 0.022 240)",
                        boxShadow: isLabRunning
                          ? "none"
                          : "0 4px 16px oklch(0.75 0.15 160 / 0.35)",
                      }}
                    >
                      {launchMut.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                      Launch Lab
                    </button>

                    <button
                      type="button"
                      data-ocid="lab.stop_lab.button"
                      onClick={handleStop}
                      disabled={!isLabRunning || stopMut.isPending}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                      style={{
                        background: "oklch(0.19 0.045 235)",
                        border: "1px solid oklch(0.72 0.14 75)",
                        color: "oklch(0.72 0.14 75)",
                      }}
                    >
                      {stopMut.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                      Stop Lab
                    </button>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button
                          type="button"
                          data-ocid="lab.destroy_lab.open_modal_button"
                          disabled={
                            status !== LabStatus.Running &&
                            status !== LabStatus.Stopped
                          }
                          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold uppercase tracking-wider transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                          style={{
                            background: "oklch(0.53 0.17 25 / 0.15)",
                            border: "1px solid oklch(0.53 0.17 25 / 0.6)",
                            color: "oklch(0.75 0.12 25)",
                          }}
                        >
                          {destroyMut.isPending ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Trash2 className="w-4 h-4" />
                          )}
                          Destroy Lab
                        </button>
                      </AlertDialogTrigger>
                      <AlertDialogContent
                        data-ocid="lab.destroy_lab.dialog"
                        style={{
                          background: "oklch(0.14 0.032 238)",
                          border: "1px solid oklch(0.28 0.055 240)",
                        }}
                      >
                        <AlertDialogHeader>
                          <AlertDialogTitle
                            style={{ color: "oklch(0.92 0.02 240)" }}
                          >
                            Destroy Lab Container?
                          </AlertDialogTitle>
                          <AlertDialogDescription
                            style={{ color: "oklch(0.57 0.05 240)" }}
                          >
                            This will permanently remove the Docker container.
                            All unsaved progress will be lost.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel
                            data-ocid="lab.destroy_lab.cancel_button"
                            style={{
                              background: "oklch(0.19 0.045 235)",
                              color: "oklch(0.92 0.02 240)",
                              border: "1px solid oklch(0.28 0.055 240)",
                            }}
                          >
                            Cancel
                          </AlertDialogCancel>
                          <AlertDialogAction
                            data-ocid="lab.destroy_lab.confirm_button"
                            onClick={handleDestroy}
                            style={{
                              background: "oklch(0.53 0.17 25)",
                              color: "oklch(0.92 0.02 240)",
                            }}
                          >
                            Destroy Container
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>

                {/* Re-launch after destroy */}
                {status === LabStatus.Destroyed && (
                  <div
                    className="rounded-xl p-4 flex items-center justify-between"
                    style={{
                      background: "oklch(0.75 0.15 160 / 0.08)",
                      border: "1px solid oklch(0.75 0.15 160 / 0.3)",
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle
                        className="w-4 h-4"
                        style={{ color: "oklch(0.75 0.15 160)" }}
                      />
                      <span
                        className="text-sm"
                        style={{ color: "oklch(0.92 0.02 240)" }}
                      >
                        Container destroyed. Ready to re-launch.
                      </span>
                    </div>
                    <button
                      type="button"
                      data-ocid="lab.relaunch.button"
                      onClick={handleLaunch}
                      className="px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider"
                      style={{
                        background: "oklch(0.75 0.15 160)",
                        color: "oklch(0.085 0.022 240)",
                      }}
                    >
                      Re-Launch
                    </button>
                  </div>
                )}
              </motion.div>
            ) : null}
          </div>
        </div>

        <footer
          className="px-8 py-3 border-t text-center"
          style={{ borderColor: "oklch(0.28 0.055 240)" }}
        >
          <p className="text-xs" style={{ color: "oklch(0.40 0.04 240)" }}>
            © {new Date().getFullYear()}. Built with ❤ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noreferrer"
              style={{ color: "oklch(0.80 0.13 200)" }}
            >
              caffeine.ai
            </a>{" "}
            · SYSTEM OPERATIONAL
          </p>
        </footer>
      </main>
    </div>
  );
}
