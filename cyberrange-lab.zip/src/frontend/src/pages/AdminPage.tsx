import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Edit,
  Loader2,
  Play,
  Plus,
  RefreshCw,
  Square,
  Trash2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { LabDetail, LabInstance, User } from "../backend.d";
import { LabDifficulty, LabStatus } from "../backend.d";
import Sidebar from "../components/Sidebar";
import {
  useAdminCreateLab,
  useAdminCreateUser,
  useAdminDeleteLab,
  useAdminDeleteUser,
  useAdminDestroyLab,
  useAdminGetAllLabInstances,
  useAdminGetAllUsers,
  useAdminLaunchLab,
  useAdminStopLab,
  useAdminUpdateLab,
  useAdminUpdateUser,
  useGetLabDetail,
  useGetLabs,
} from "../hooks/useQueries";

// ─── Color constants ─────────────────────────────────────────────────────────
const C = {
  bg: "oklch(0.085 0.022 240)",
  card: "oklch(0.14 0.032 238)",
  cardDeep: "oklch(0.11 0.025 240)",
  border: "oklch(0.28 0.055 240)",
  text: "oklch(0.92 0.02 240)",
  muted: "oklch(0.57 0.05 240)",
  accent: "oklch(0.80 0.13 200)",
  success: "oklch(0.75 0.15 160)",
  warning: "oklch(0.72 0.14 75)",
  danger: "oklch(0.65 0.17 25)",
  dangerBg: "oklch(0.53 0.17 25 / 0.15)",
};

// ─── Status badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  let color = C.muted;
  let bg = "oklch(0.28 0.055 240 / 0.3)";
  if (status === LabStatus.Running) {
    color = C.success;
    bg = "oklch(0.75 0.15 160 / 0.15)";
  } else if (status === LabStatus.Stopped) {
    color = C.warning;
    bg = "oklch(0.72 0.14 75 / 0.15)";
  } else if (status === LabStatus.Destroyed) {
    color = C.danger;
    bg = C.dangerBg;
  }
  return (
    <span
      className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md inline-flex items-center gap-1"
      style={{ color, background: bg }}
    >
      {status === LabStatus.Running && (
        <span
          className="w-1.5 h-1.5 rounded-full animate-pulse"
          style={{ background: color }}
        />
      )}
      {status}
    </span>
  );
}

// ─── Difficulty badge ─────────────────────────────────────────────────────────
function DiffBadge({ diff }: { diff: string }) {
  const map: Record<string, { color: string; bg: string }> = {
    [LabDifficulty.Easy]: {
      color: C.success,
      bg: "oklch(0.75 0.15 160 / 0.15)",
    },
    [LabDifficulty.Medium]: {
      color: C.warning,
      bg: "oklch(0.72 0.14 75 / 0.15)",
    },
    [LabDifficulty.Hard]: {
      color: "oklch(0.53 0.17 25)",
      bg: "oklch(0.53 0.17 25 / 0.15)",
    },
    [LabDifficulty.Extreme]: {
      color: "oklch(0.54 0.22 290)",
      bg: "oklch(0.54 0.22 290 / 0.15)",
    },
  };
  const m = map[diff] || map[LabDifficulty.Easy];
  return (
    <span
      className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
      style={{ color: m.color, background: m.bg }}
    >
      {diff}
    </span>
  );
}

// ─── Generic table wrapper ────────────────────────────────────────────────────
function TableWrap({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ border: `1px solid ${C.border}` }}
    >
      <table className="w-full text-sm">{children}</table>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th
      className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider"
      style={{
        color: C.muted,
        background: C.cardDeep,
        borderBottom: `1px solid ${C.border}`,
      }}
    >
      {children}
    </th>
  );
}

function Td({
  children,
  className,
  colSpan,
}: { children: React.ReactNode; className?: string; colSpan?: number }) {
  return (
    <td
      className={`px-4 py-3 ${className || ""}`}
      colSpan={colSpan}
      style={{ color: C.text, borderBottom: `1px solid ${C.border}` }}
    >
      {children}
    </td>
  );
}

// ─── Lab Form Dialog ──────────────────────────────────────────────────────────
interface LabTool {
  _id: string;
  name: string;
  description: string;
}

interface LabFormData {
  name: string;
  difficulty: LabDifficulty;
  description: string;
  howToUse: string;
  estimatedDuration: number;
  tools: LabTool[];
}

const defaultLabForm: LabFormData = {
  name: "",
  difficulty: LabDifficulty.Easy,
  description: "",
  howToUse: "",
  estimatedDuration: 60,
  tools: [],
};

function LabFormDialog({
  open,
  onClose,
  initial,
  editId,
}: {
  open: boolean;
  onClose: () => void;
  initial?: LabFormData;
  editId?: bigint;
}) {
  const [form, setForm] = useState<LabFormData>(initial || defaultLabForm);
  const createLab = useAdminCreateLab();
  const updateLab = useAdminUpdateLab();
  const isPending = createLab.isPending || updateLab.isPending;

  function handleSave() {
    if (!form.name.trim()) {
      toast.error("Lab name is required");
      return;
    }
    if (editId !== undefined) {
      updateLab.mutate(
        { labId: editId, ...form },
        {
          onSuccess: () => {
            toast.success("Lab updated successfully");
            onClose();
          },
          onError: (err) => toast.error(err.message || "Failed to update lab"),
        },
      );
    } else {
      createLab.mutate(
        { ...form, tools: form.tools },
        {
          onSuccess: () => {
            toast.success("Lab created successfully");
            onClose();
          },
          onError: (err) => toast.error(err.message || "Failed to create lab"),
        },
      );
    }
  }

  // Reset form when dialog opens
  function handleOpenChange(isOpen: boolean) {
    if (!isOpen) onClose();
    else setForm(initial || defaultLabForm);
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        className="max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        style={{
          background: C.card,
          border: `1px solid ${C.border}`,
          color: C.text,
        }}
        data-ocid="admin.lab.dialog"
      >
        <DialogHeader>
          <DialogTitle style={{ color: C.text }}>
            {editId !== undefined ? "Edit Lab" : "Create New Lab"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div>
            <Label
              style={{ color: C.muted }}
              className="text-xs uppercase tracking-wider mb-1 block"
            >
              Lab Name
            </Label>
            <Input
              data-ocid="admin.lab.input"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="Network Penetration Testing"
              style={{
                background: C.cardDeep,
                border: `1px solid ${C.border}`,
                color: C.text,
              }}
            />
          </div>
          <div>
            <Label
              style={{ color: C.muted }}
              className="text-xs uppercase tracking-wider mb-1 block"
            >
              Difficulty
            </Label>
            <Select
              value={form.difficulty}
              onValueChange={(v) =>
                setForm((f) => ({ ...f, difficulty: v as LabDifficulty }))
              }
            >
              <SelectTrigger
                data-ocid="admin.lab.select"
                style={{
                  background: C.cardDeep,
                  border: `1px solid ${C.border}`,
                  color: C.text,
                }}
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent
                style={{ background: C.card, border: `1px solid ${C.border}` }}
              >
                {Object.values(LabDifficulty).map((d) => (
                  <SelectItem key={d} value={d} style={{ color: C.text }}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label
              style={{ color: C.muted }}
              className="text-xs uppercase tracking-wider mb-1 block"
            >
              Description
            </Label>
            <Textarea
              data-ocid="admin.lab.textarea"
              value={form.description}
              onChange={(e) =>
                setForm((f) => ({ ...f, description: e.target.value }))
              }
              placeholder="Describe the lab objectives..."
              rows={3}
              style={{
                background: C.cardDeep,
                border: `1px solid ${C.border}`,
                color: C.text,
              }}
            />
          </div>
          <div>
            <Label
              style={{ color: C.muted }}
              className="text-xs uppercase tracking-wider mb-1 block"
            >
              How to Use
            </Label>
            <Textarea
              value={form.howToUse}
              onChange={(e) =>
                setForm((f) => ({ ...f, howToUse: e.target.value }))
              }
              placeholder="Step-by-step instructions..."
              rows={3}
              style={{
                background: C.cardDeep,
                border: `1px solid ${C.border}`,
                color: C.text,
              }}
            />
          </div>
          <div>
            <Label
              style={{ color: C.muted }}
              className="text-xs uppercase tracking-wider mb-1 block"
            >
              Estimated Duration (minutes)
            </Label>
            <Input
              type="number"
              min={1}
              value={form.estimatedDuration}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  estimatedDuration: Number(e.target.value) || 60,
                }))
              }
              style={{
                background: C.cardDeep,
                border: `1px solid ${C.border}`,
                color: C.text,
              }}
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <Label
                style={{ color: C.muted }}
                className="text-xs uppercase tracking-wider block"
              >
                Installed Tools
              </Label>
              <button
                type="button"
                onClick={() =>
                  setForm((f) => ({
                    ...f,
                    tools: [
                      ...f.tools,
                      { _id: crypto.randomUUID(), name: "", description: "" },
                    ],
                  }))
                }
                className="text-xs px-2 py-0.5 rounded-md font-medium"
                style={{
                  color: C.accent,
                  background: "oklch(0.80 0.13 200 / 0.1)",
                }}
              >
                + Add Tool
              </button>
            </div>
            {form.tools.length === 0 && (
              <p className="text-xs py-2" style={{ color: C.muted }}>
                No tools added. Click "+ Add Tool" to add installed tools.
              </p>
            )}
            <div className="space-y-2 mt-1">
              {form.tools.map((tool, idx) => (
                <div key={tool._id} className="flex gap-2 items-start">
                  <div className="flex-1 space-y-1">
                    <Input
                      placeholder="Tool name (e.g. nmap)"
                      value={tool.name}
                      onChange={(e) =>
                        setForm((f) => {
                          const tools = [...f.tools];
                          tools[idx] = { ...tools[idx], name: e.target.value };
                          return { ...f, tools };
                        })
                      }
                      style={{
                        background: C.cardDeep,
                        border: `1px solid ${C.border}`,
                        color: C.text,
                        fontSize: "0.75rem",
                        height: "2rem",
                      }}
                    />
                    <Input
                      placeholder="Short description"
                      value={tool.description}
                      onChange={(e) =>
                        setForm((f) => {
                          const tools = [...f.tools];
                          tools[idx] = {
                            ...tools[idx],
                            description: e.target.value,
                          };
                          return { ...f, tools };
                        })
                      }
                      style={{
                        background: C.cardDeep,
                        border: `1px solid ${C.border}`,
                        color: C.text,
                        fontSize: "0.75rem",
                        height: "2rem",
                      }}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        tools: f.tools.filter((_, i) => i !== idx),
                      }))
                    }
                    className="p-1.5 rounded-lg mt-0.5"
                    style={{ color: C.danger, background: C.dangerBg }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button
            data-ocid="admin.lab.cancel_button"
            variant="ghost"
            onClick={onClose}
            style={{ color: C.muted }}
          >
            Cancel
          </Button>
          <Button
            data-ocid="admin.lab.save_button"
            onClick={handleSave}
            disabled={isPending}
            style={{
              background: `linear-gradient(135deg, ${C.accent}, ${C.success})`,
              color: C.bg,
            }}
          >
            {isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            {editId !== undefined ? "Update Lab" : "Create Lab"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Users Tab ────────────────────────────────────────────────────────────────
function UsersTab() {
  const { data: users, isLoading } = useAdminGetAllUsers();
  const createUser = useAdminCreateUser();
  const updateUser = useAdminUpdateUser();
  const deleteUser = useAdminDeleteUser();

  const [createOpen, setCreateOpen] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [editPassword, setEditPassword] = useState("");

  const adminEmail = localStorage.getItem("cr_email") || "";

  function handleCreate() {
    if (!newEmail.trim() || !newPassword.trim()) {
      toast.error("Email and password are required");
      return;
    }
    createUser.mutate(
      { email: newEmail.trim(), password: newPassword },
      {
        onSuccess: () => {
          toast.success("User created");
          setCreateOpen(false);
          setNewEmail("");
          setNewPassword("");
        },
        onError: (err) => toast.error(err.message || "Failed to create user"),
      },
    );
  }

  function handleUpdate() {
    if (!editUser || !editPassword.trim()) {
      toast.error("New password is required");
      return;
    }
    updateUser.mutate(
      { email: editUser.email, newPassword: editPassword },
      {
        onSuccess: () => {
          toast.success("Password updated");
          setEditUser(null);
          setEditPassword("");
        },
        onError: (err) => toast.error(err.message || "Failed to update user"),
      },
    );
  }

  function handleDelete(email: string) {
    deleteUser.mutate(email, {
      onSuccess: () => {
        toast.success("User deleted");
        setDeleteConfirm(null);
      },
      onError: (err) => toast.error(err.message || "Failed to delete user"),
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold" style={{ color: C.text }}>
          User Management
        </h2>
        <Button
          data-ocid="admin.users.open_modal_button"
          onClick={() => setCreateOpen(true)}
          size="sm"
          style={{
            background: `linear-gradient(135deg, ${C.accent}, ${C.success})`,
            color: C.bg,
          }}
        >
          <Plus className="w-4 h-4 mr-1" /> Create User
        </Button>
      </div>

      {isLoading ? (
        <div
          data-ocid="admin.users.loading_state"
          className="py-12 text-center"
          style={{ color: C.muted }}
        >
          Loading users...
        </div>
      ) : (
        <TableWrap>
          <thead>
            <tr>
              <Th>Email</Th>
              <Th>Role</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {(users || []).length === 0 ? (
              <tr>
                <Td className="text-center" colSpan={3}>
                  <span style={{ color: C.muted }}>No users found</span>
                </Td>
              </tr>
            ) : (
              (users || []).map((u, i) => {
                const isAdminUser =
                  u.email === adminEmail || u.email.includes("admin");
                return (
                  <tr
                    key={u.email}
                    data-ocid={`admin.users.item.${i + 1}`}
                    style={{ background: i % 2 === 0 ? C.card : C.cardDeep }}
                  >
                    <Td>
                      <span className="font-mono text-xs">{u.email}</span>
                    </Td>
                    <Td>
                      <span
                        className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                        style={{
                          color: isAdminUser ? C.accent : C.success,
                          background: isAdminUser
                            ? "oklch(0.80 0.13 200 / 0.15)"
                            : "oklch(0.75 0.15 160 / 0.15)",
                        }}
                      >
                        {isAdminUser ? "Administrator" : "Operator"}
                      </span>
                    </Td>
                    <Td>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          data-ocid={`admin.users.edit_button.${i + 1}`}
                          onClick={() => {
                            setEditUser(u);
                            setEditPassword("");
                          }}
                          className="p-1.5 rounded-lg transition-colors"
                          style={{
                            color: C.accent,
                            background: "oklch(0.80 0.13 200 / 0.1)",
                          }}
                          title="Edit password"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        {!isAdminUser && (
                          <button
                            type="button"
                            data-ocid={`admin.users.delete_button.${i + 1}`}
                            onClick={() => setDeleteConfirm(u.email)}
                            className="p-1.5 rounded-lg transition-colors"
                            style={{ color: C.danger, background: C.dangerBg }}
                            title="Delete user"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </Td>
                  </tr>
                );
              })
            )}
          </tbody>
        </TableWrap>
      )}

      {/* Create User Dialog */}
      <Dialog
        open={createOpen}
        onOpenChange={(o) => {
          setCreateOpen(o);
          if (!o) {
            setNewEmail("");
            setNewPassword("");
          }
        }}
      >
        <DialogContent
          style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            color: C.text,
          }}
          data-ocid="admin.create_user.dialog"
        >
          <DialogHeader>
            <DialogTitle style={{ color: C.text }}>Create New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label
                style={{ color: C.muted }}
                className="text-xs uppercase tracking-wider mb-1 block"
              >
                Email
              </Label>
              <Input
                data-ocid="admin.create_user.input"
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="operator@cyberrange.io"
                style={{
                  background: C.cardDeep,
                  border: `1px solid ${C.border}`,
                  color: C.text,
                }}
              />
            </div>
            <div>
              <Label
                style={{ color: C.muted }}
                className="text-xs uppercase tracking-wider mb-1 block"
              >
                Password
              </Label>
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                style={{
                  background: C.cardDeep,
                  border: `1px solid ${C.border}`,
                  color: C.text,
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              data-ocid="admin.create_user.cancel_button"
              variant="ghost"
              onClick={() => setCreateOpen(false)}
              style={{ color: C.muted }}
            >
              Cancel
            </Button>
            <Button
              data-ocid="admin.create_user.submit_button"
              onClick={handleCreate}
              disabled={createUser.isPending}
              style={{
                background: `linear-gradient(135deg, ${C.accent}, ${C.success})`,
                color: C.bg,
              }}
            >
              {createUser.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Create User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog
        open={!!editUser}
        onOpenChange={(o) => {
          if (!o) setEditUser(null);
        }}
      >
        <DialogContent
          style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            color: C.text,
          }}
          data-ocid="admin.edit_user.dialog"
        >
          <DialogHeader>
            <DialogTitle style={{ color: C.text }}>Change Password</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <p className="text-sm" style={{ color: C.muted }}>
              Updating password for:{" "}
              <span className="font-mono" style={{ color: C.text }}>
                {editUser?.email}
              </span>
            </p>
            <div>
              <Label
                style={{ color: C.muted }}
                className="text-xs uppercase tracking-wider mb-1 block"
              >
                New Password
              </Label>
              <Input
                data-ocid="admin.edit_user.input"
                type="password"
                value={editPassword}
                onChange={(e) => setEditPassword(e.target.value)}
                placeholder="••••••••"
                style={{
                  background: C.cardDeep,
                  border: `1px solid ${C.border}`,
                  color: C.text,
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              data-ocid="admin.edit_user.cancel_button"
              variant="ghost"
              onClick={() => setEditUser(null)}
              style={{ color: C.muted }}
            >
              Cancel
            </Button>
            <Button
              data-ocid="admin.edit_user.submit_button"
              onClick={handleUpdate}
              disabled={updateUser.isPending}
              style={{
                background: `linear-gradient(135deg, ${C.accent}, ${C.success})`,
                color: C.bg,
              }}
            >
              {updateUser.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Update Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm Dialog */}
      <Dialog
        open={!!deleteConfirm}
        onOpenChange={(o) => {
          if (!o) setDeleteConfirm(null);
        }}
      >
        <DialogContent
          style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            color: C.text,
          }}
          data-ocid="admin.delete_user.dialog"
        >
          <DialogHeader>
            <DialogTitle style={{ color: C.danger }}>Delete User</DialogTitle>
          </DialogHeader>
          <p className="text-sm py-2" style={{ color: C.muted }}>
            Are you sure you want to delete{" "}
            <span className="font-mono" style={{ color: C.text }}>
              {deleteConfirm}
            </span>
            ? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button
              data-ocid="admin.delete_user.cancel_button"
              variant="ghost"
              onClick={() => setDeleteConfirm(null)}
              style={{ color: C.muted }}
            >
              Cancel
            </Button>
            <Button
              data-ocid="admin.delete_user.confirm_button"
              onClick={() => deleteConfirm && handleDelete(deleteConfirm)}
              disabled={deleteUser.isPending}
              style={{ background: C.danger, color: "white" }}
            >
              {deleteUser.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Delete User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Sessions Tab ─────────────────────────────────────────────────────────────
function SessionsTab() {
  const {
    data: instances,
    isLoading,
    refetch,
    isFetching,
  } = useAdminGetAllLabInstances();
  const { data: labs } = useGetLabs();
  const launchLab = useAdminLaunchLab();
  const stopLab = useAdminStopLab();
  const destroyLab = useAdminDestroyLab();
  const [destroyConfirm, setDestroyConfirm] = useState<LabInstance | null>(
    null,
  );

  function labName(labId: bigint) {
    return (
      labs?.find((l) => l.id.toString() === labId.toString())?.name ||
      `Lab #${labId}`
    );
  }

  function formatTime(ts?: bigint) {
    if (!ts) return "—";
    return new Date(Number(ts) / 1_000_000).toLocaleString();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold" style={{ color: C.text }}>
          Session Oversight
        </h2>
        <Button
          data-ocid="admin.sessions.button"
          onClick={() => refetch()}
          variant="outline"
          size="sm"
          disabled={isFetching}
          style={{ borderColor: C.border, color: C.muted }}
        >
          <RefreshCw
            className={`w-4 h-4 mr-1 ${isFetching ? "animate-spin" : ""}`}
          />
          Refresh
        </Button>
      </div>

      {isLoading ? (
        <div
          data-ocid="admin.sessions.loading_state"
          className="py-12 text-center"
          style={{ color: C.muted }}
        >
          Loading sessions...
        </div>
      ) : (
        <TableWrap>
          <thead>
            <tr>
              <Th>User</Th>
              <Th>Lab</Th>
              <Th>Container ID</Th>
              <Th>Status</Th>
              <Th>Start Time</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {(instances || []).length === 0 ? (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-12 text-center"
                  style={{
                    color: C.muted,
                    borderBottom: `1px solid ${C.border}`,
                  }}
                >
                  No active sessions
                </td>
              </tr>
            ) : (
              (instances || []).map((inst, i) => (
                <tr
                  key={`${inst.userEmail}-${inst.labId}-${i}`}
                  data-ocid={`admin.sessions.item.${i + 1}`}
                  style={{ background: i % 2 === 0 ? C.card : C.cardDeep }}
                >
                  <Td>
                    <span className="font-mono text-xs">{inst.userEmail}</span>
                  </Td>
                  <Td>{labName(inst.labId)}</Td>
                  <Td>
                    <span
                      className="font-mono text-xs"
                      style={{ color: C.muted }}
                    >
                      {inst.containerId
                        ? `${inst.containerId.slice(0, 12)}...`
                        : "—"}
                    </span>
                  </Td>
                  <Td>
                    <StatusBadge status={inst.status} />
                  </Td>
                  <Td>
                    <span className="text-xs" style={{ color: C.muted }}>
                      {formatTime(inst.startTime)}
                    </span>
                  </Td>
                  <Td>
                    <div className="flex items-center gap-2">
                      {inst.status === LabStatus.Stopped && (
                        <button
                          type="button"
                          data-ocid={`admin.sessions.button.${i + 1}`}
                          onClick={() =>
                            launchLab.mutate(
                              { userEmail: inst.userEmail, labId: inst.labId },
                              {
                                onSuccess: () => toast.success("Lab started"),
                                onError: (e) =>
                                  toast.error(e.message || "Failed to start"),
                              },
                            )
                          }
                          className="p-1.5 rounded-lg"
                          style={{
                            color: C.success,
                            background: "oklch(0.75 0.15 160 / 0.1)",
                          }}
                          title="Start"
                        >
                          <Play className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {inst.status === LabStatus.Running && (
                        <button
                          type="button"
                          data-ocid={`admin.sessions.button.${i + 1}`}
                          onClick={() =>
                            stopLab.mutate(
                              { userEmail: inst.userEmail, labId: inst.labId },
                              {
                                onSuccess: () => toast.success("Lab stopped"),
                                onError: (e) =>
                                  toast.error(e.message || "Failed to stop"),
                              },
                            )
                          }
                          className="p-1.5 rounded-lg"
                          style={{
                            color: C.warning,
                            background: "oklch(0.72 0.14 75 / 0.1)",
                          }}
                          title="Stop"
                        >
                          <Square className="w-3.5 h-3.5" />
                        </button>
                      )}
                      {(inst.status === LabStatus.Running ||
                        inst.status === LabStatus.Stopped) && (
                        <button
                          type="button"
                          data-ocid={`admin.sessions.delete_button.${i + 1}`}
                          onClick={() => setDestroyConfirm(inst)}
                          className="p-1.5 rounded-lg"
                          style={{ color: C.danger, background: C.dangerBg }}
                          title="Destroy"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </Td>
                </tr>
              ))
            )}
          </tbody>
        </TableWrap>
      )}

      {/* Destroy Confirm */}
      <Dialog
        open={!!destroyConfirm}
        onOpenChange={(o) => {
          if (!o) setDestroyConfirm(null);
        }}
      >
        <DialogContent
          style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            color: C.text,
          }}
          data-ocid="admin.destroy_lab.dialog"
        >
          <DialogHeader>
            <DialogTitle style={{ color: C.danger }}>
              Destroy Lab Instance
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm py-2" style={{ color: C.muted }}>
            Permanently destroy{" "}
            <span style={{ color: C.text }}>
              {destroyConfirm ? labName(destroyConfirm.labId) : ""}
            </span>{" "}
            for user{" "}
            <span className="font-mono" style={{ color: C.text }}>
              {destroyConfirm?.userEmail}
            </span>
            ? This cannot be undone.
          </p>
          <DialogFooter>
            <Button
              data-ocid="admin.destroy_lab.cancel_button"
              variant="ghost"
              onClick={() => setDestroyConfirm(null)}
              style={{ color: C.muted }}
            >
              Cancel
            </Button>
            <Button
              data-ocid="admin.destroy_lab.confirm_button"
              onClick={() => {
                if (!destroyConfirm) return;
                destroyLab.mutate(
                  {
                    userEmail: destroyConfirm.userEmail,
                    labId: destroyConfirm.labId,
                  },
                  {
                    onSuccess: () => {
                      toast.success("Lab destroyed");
                      setDestroyConfirm(null);
                    },
                    onError: (e) =>
                      toast.error(e.message || "Failed to destroy"),
                  },
                );
              }}
              disabled={destroyLab.isPending}
              style={{ background: C.danger, color: "white" }}
            >
              {destroyLab.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Destroy
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Labs Tab ─────────────────────────────────────────────────────────────────
function LabsTab() {
  const { data: labs, isLoading } = useGetLabs();
  const deleteLab = useAdminDeleteLab();

  const [labFormOpen, setLabFormOpen] = useState(false);
  const [editLab, setEditLab] = useState<{
    id: bigint;
    form: LabFormData;
  } | null>(null);
  const [editLabId, setEditLabId] = useState<bigint | null>(null);
  const { data: editLabDetail } = useGetLabDetail(editLabId ?? 0n);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    id: bigint;
    name: string;
  } | null>(null);

  // Once lab detail loads, update the edit form with full data (description, howToUse, tools)
  // biome-ignore lint/correctness/useExhaustiveDependencies: only run when editLabDetail changes to avoid infinite loop
  useEffect(() => {
    if (!editLabDetail) return;
    setEditLab((prev) =>
      prev && prev.id === editLabDetail.id
        ? {
            ...prev,
            form: {
              ...prev.form,
              description: editLabDetail.description,
              howToUse: editLabDetail.howToUse,
              tools: editLabDetail.tools.map(
                (t: { name: string; description: string }) => ({
                  ...t,
                  _id: crypto.randomUUID(),
                }),
              ),
            },
          }
        : prev,
    );
  }, [editLabDetail]);

  function handleDeleteLab(labId: bigint) {
    deleteLab.mutate(labId, {
      onSuccess: () => {
        toast.success("Lab deleted");
        setDeleteConfirm(null);
      },
      onError: (e) => toast.error(e.message || "Failed to delete lab"),
    });
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold" style={{ color: C.text }}>
          Lab Management
        </h2>
        <Button
          data-ocid="admin.labs.open_modal_button"
          onClick={() => setLabFormOpen(true)}
          size="sm"
          style={{
            background: `linear-gradient(135deg, ${C.accent}, ${C.success})`,
            color: C.bg,
          }}
        >
          <Plus className="w-4 h-4 mr-1" /> Create Lab
        </Button>
      </div>

      {isLoading ? (
        <div
          data-ocid="admin.labs.loading_state"
          className="py-12 text-center"
          style={{ color: C.muted }}
        >
          Loading labs...
        </div>
      ) : (
        <TableWrap>
          <thead>
            <tr>
              <Th>Name</Th>
              <Th>Difficulty</Th>
              <Th>Duration</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {(labs || []).length === 0 ? (
              <tr>
                <td
                  colSpan={4}
                  className="px-4 py-12 text-center"
                  style={{
                    color: C.muted,
                    borderBottom: `1px solid ${C.border}`,
                  }}
                >
                  No labs configured
                </td>
              </tr>
            ) : (
              (labs || []).map((lab, i) => (
                <tr
                  key={lab.id.toString()}
                  data-ocid={`admin.labs.item.${i + 1}`}
                  style={{ background: i % 2 === 0 ? C.card : C.cardDeep }}
                >
                  <Td>
                    <span className="font-medium">{lab.name}</span>
                  </Td>
                  <Td>
                    <DiffBadge diff={lab.difficulty} />
                  </Td>
                  <Td>
                    <span className="text-xs" style={{ color: C.muted }}>
                      {Number(lab.estimatedDuration)} min
                    </span>
                  </Td>
                  <Td>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        data-ocid={`admin.labs.edit_button.${i + 1}`}
                        onClick={() => {
                          setEditLabId(lab.id);
                          setEditLab({
                            id: lab.id,
                            form: {
                              name: lab.name,
                              difficulty: lab.difficulty as LabDifficulty,
                              description: editLabDetail?.description ?? "",
                              howToUse: editLabDetail?.howToUse ?? "",
                              estimatedDuration: Number(lab.estimatedDuration),
                              tools: (editLabDetail?.tools ?? []).map(
                                (t: { name: string; description: string }) => ({
                                  ...t,
                                  _id: crypto.randomUUID(),
                                }),
                              ),
                            },
                          });
                        }}
                        className="p-1.5 rounded-lg"
                        style={{
                          color: C.accent,
                          background: "oklch(0.80 0.13 200 / 0.1)",
                        }}
                        title="Edit lab"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        data-ocid={`admin.labs.delete_button.${i + 1}`}
                        onClick={() =>
                          setDeleteConfirm({ id: lab.id, name: lab.name })
                        }
                        className="p-1.5 rounded-lg"
                        style={{ color: C.danger, background: C.dangerBg }}
                        title="Delete lab"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </Td>
                </tr>
              ))
            )}
          </tbody>
        </TableWrap>
      )}

      {/* Create Lab */}
      <LabFormDialog open={labFormOpen} onClose={() => setLabFormOpen(false)} />

      {/* Edit Lab */}
      {editLab && (
        <LabFormDialog
          open
          onClose={() => setEditLab(null)}
          initial={editLab.form}
          editId={editLab.id}
        />
      )}

      {/* Delete Confirm */}
      <Dialog
        open={!!deleteConfirm}
        onOpenChange={(o) => {
          if (!o) setDeleteConfirm(null);
        }}
      >
        <DialogContent
          style={{
            background: C.card,
            border: `1px solid ${C.border}`,
            color: C.text,
          }}
          data-ocid="admin.delete_lab.dialog"
        >
          <DialogHeader>
            <DialogTitle style={{ color: C.danger }}>Delete Lab</DialogTitle>
          </DialogHeader>
          <p className="text-sm py-2" style={{ color: C.muted }}>
            Permanently delete{" "}
            <span style={{ color: C.text }}>{deleteConfirm?.name}</span>? All
            associated sessions will be affected.
          </p>
          <DialogFooter>
            <Button
              data-ocid="admin.delete_lab.cancel_button"
              variant="ghost"
              onClick={() => setDeleteConfirm(null)}
              style={{ color: C.muted }}
            >
              Cancel
            </Button>
            <Button
              data-ocid="admin.delete_lab.confirm_button"
              onClick={() => deleteConfirm && handleDeleteLab(deleteConfirm.id)}
              disabled={deleteLab.isPending}
              style={{ background: C.danger, color: "white" }}
            >
              {deleteLab.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Delete Lab
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function AdminPage() {
  return (
    <div className="flex min-h-screen" style={{ background: C.bg }}>
      <Sidebar activePage="admin" />
      <main className="flex-1 ml-64 flex flex-col min-h-screen">
        <header
          className="sticky top-0 z-10 flex items-center justify-between px-8 py-4"
          style={{
            background: `${C.bg}f2`,
            borderBottom: `1px solid ${C.border}`,
            backdropFilter: "blur(8px)",
          }}
        >
          <div>
            <h1 className="text-xl font-bold" style={{ color: C.text }}>
              Admin Panel
            </h1>
            <p className="text-xs" style={{ color: C.muted }}>
              Platform Management &amp; Oversight
            </p>
          </div>
          <div
            className="px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider"
            style={{
              color: C.accent,
              background: "oklch(0.80 0.13 200 / 0.12)",
              border: "1px solid oklch(0.80 0.13 200 / 0.3)",
            }}
          >
            Administrator
          </div>
        </header>

        <div className="flex-1 px-8 py-6">
          <Tabs defaultValue="users" data-ocid="admin.tab">
            <TabsList
              className="mb-6"
              style={{
                background: C.cardDeep,
                border: `1px solid ${C.border}`,
              }}
            >
              <TabsTrigger
                value="users"
                data-ocid="admin.users.tab"
                className="data-[state=active]:text-[oklch(0.80_0.13_200)]"
              >
                Users
              </TabsTrigger>
              <TabsTrigger
                value="sessions"
                data-ocid="admin.sessions.tab"
                className="data-[state=active]:text-[oklch(0.80_0.13_200)]"
              >
                Sessions
              </TabsTrigger>
              <TabsTrigger
                value="labs"
                data-ocid="admin.labs.tab"
                className="data-[state=active]:text-[oklch(0.80_0.13_200)]"
              >
                Labs
              </TabsTrigger>
            </TabsList>
            <TabsContent value="users">
              <UsersTab />
            </TabsContent>
            <TabsContent value="sessions">
              <SessionsTab />
            </TabsContent>
            <TabsContent value="labs">
              <LabsTab />
            </TabsContent>
          </Tabs>
        </div>

        <footer
          className="px-8 py-4 border-t text-center"
          style={{ borderColor: C.border }}
        >
          <p className="text-xs" style={{ color: "oklch(0.40 0.04 240)" }}>
            © {new Date().getFullYear()}. Built with ❤ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noreferrer"
              style={{ color: C.accent }}
            >
              caffeine.ai
            </a>
          </p>
        </footer>
      </main>
    </div>
  );
}
