import {
  CheckCheck,
  Copy,
  Database,
  Package,
  Play,
  Server,
  Terminal,
} from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import Sidebar from "../components/Sidebar";

const PYTHON_BACKEND = `#!/usr/bin/env python3
"""
CyberRange Local Backend
Requires: pip install flask flask-cors apscheduler
"""

import sqlite3, hashlib, secrets, datetime, json, os, subprocess, random
from flask import Flask, request, jsonify
from flask_cors import CORS
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)
CORS(app)
DB_PATH = "cyberrange.db"
LAB_TIMEOUT_SECONDS = 7200
COMPOSE_DIR = os.path.join(os.path.dirname(__file__), "kali_labs")

COMPOSE_TEMPLATE = """version: "3.8"
services:
  kali-desktop:
    image: lscr.io/linuxserver/kali-linux:latest
    environment:
      - PUID=1000
      - PGID=1000
      - TZ=Asia/Kolkata
      - SUBFOLDER=/
      - TITLE=Kali Desktop
      - PASSWORD={password}
    ports:
      - "{port}:3000"
    volumes:
      - ./config:/config
    cap_add:
      - NET_ADMIN
      - NET_RAW
    shm_size: "1gb"
    restart: unless-stopped
"""

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        email TEXT NOT NULL,
        created_at REAL NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS labs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        description TEXT,
        tools TEXT,
        how_to_use TEXT,
        estimated_duration INTEGER DEFAULT 2
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS lab_instances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        lab_id INTEGER NOT NULL,
        user_email TEXT NOT NULL,
        container_id TEXT,
        status TEXT DEFAULT 'Idle',
        start_time REAL,
        port INTEGER,
        kali_password TEXT,
        UNIQUE(lab_id, user_email)
    )""")
    conn.commit()
    # Seed users
    for email, pwd in [("admin@cyberrange.io", "Admin@123"), ("user@cyberrange.io", "User@123")]:
        h = hashlib.sha256(pwd.encode()).hexdigest()
        c.execute("INSERT OR IGNORE INTO users (email, password_hash) VALUES (?,?)", (email, h))
    # Seed labs
    labs_data = [
        ("Kali Linux Desktop Lab", "Medium",
         "Full Kali Linux GUI desktop accessible via browser. Includes all standard Kali tools pre-installed.",
         json.dumps([{"name": "Nmap", "description": "Network scanner"}, {"name": "Metasploit", "description": "Exploitation framework"}, {"name": "Burp Suite", "description": "Web proxy"}, {"name": "Wireshark", "description": "Packet analyzer"}]),
         "# Step 1: Launch the lab from the dashboard\\n# Step 2: Open the noVNC URL shown in the Access panel\\n# Step 3: Enter the password shown in the Access panel\\n# Step 4: You now have a full Kali desktop in your browser\\n\\n# Tools are pre-installed - open a terminal in the desktop\\n# to start using Nmap, Metasploit, Burp, etc.", 2),
        ("Network Intrusion Lab", "Hard",
         "Master network penetration using real exploit frameworks in an isolated target environment.",
         json.dumps([{"name": "Nmap", "description": "Network scanner"}, {"name": "Metasploit", "description": "Exploitation framework"}, {"name": "Wireshark", "description": "Packet analyzer"}]),
         "# Step 1: Scan target network\\nnmap -sV -sC -p- 10.0.0.1\\n\\n# Step 2: Launch Metasploit\\nmsfconsole\\n\\n# Step 3: Search exploit\\nsearch type:exploit vsftpd\\nuse exploit/unix/ftp/vsftpd_234_backdoor\\nset RHOSTS 10.0.0.1\\nrun", 3),
        ("Web App Exploitation", "Medium",
         "Explore OWASP Top 10 vulnerabilities with live vulnerable web application targets.",
         json.dumps([{"name": "Burp Suite", "description": "Web proxy interceptor"}, {"name": "SQLMap", "description": "Automated SQL injection"}, {"name": "Nikto", "description": "Web server scanner"}]),
         "# Step 1: Configure proxy\\n# Set browser to 127.0.0.1:8080\\n\\n# Step 2: Intercept login request\\n# Forward to Repeater in Burp\\n\\n# Step 3: SQL injection test\\nsqlmap -u 'http://target/login' --data 'user=admin&pass=test' --dbs", 2),
        ("Malware Analysis", "Extreme",
         "Safely reverse-engineer real malware samples in a fully isolated sandbox environment.",
         json.dumps([{"name": "Ghidra", "description": "NSA reverse engineering suite"}, {"name": "strings", "description": "Binary string extractor"}, {"name": "strace", "description": "System call tracer"}]),
         "# Step 1: Extract strings\\nstrings malware.exe | grep -iE 'http|cmd|reg'\\n\\n# Step 2: Trace system calls\\nstrace -e trace=all ./malware\\n\\n# Step 3: Open Ghidra\\nghidraRun &", 4),
    ]
    for lab in labs_data:
        c.execute("INSERT OR IGNORE INTO labs (name,difficulty,description,tools,how_to_use,estimated_duration) VALUES (?,?,?,?,?,?)", lab)
    conn.commit()
    conn.close()

def hash_pwd(p): return hashlib.sha256(p.encode()).hexdigest()
def get_db(): return sqlite3.connect(DB_PATH)

def verify_token(token):
    conn = get_db()
    row = conn.execute("SELECT email FROM sessions WHERE token=?", (token,)).fetchone()
    conn.close()
    return row[0] if row else None

def get_compose_dir(lab_id, email):
    safe_email = email.replace("@","_").replace(".","_")
    return os.path.join(COMPOSE_DIR, f"lab_{lab_id}_{safe_email}")

def find_free_port():
    used = set()
    conn = get_db()
    rows = conn.execute("SELECT port FROM lab_instances WHERE port IS NOT NULL AND status='Running'").fetchall()
    conn.close()
    for r in rows:
        used.add(r[0])
    for port in random.sample(range(8100, 9000), 900):
        if port not in used:
            return port
    return random.randint(8100, 8999)

def expire_labs():
    conn = get_db()
    cutoff = datetime.datetime.now().timestamp() - LAB_TIMEOUT_SECONDS
    rows = conn.execute(
        "SELECT id, lab_id, user_email FROM lab_instances WHERE status='Running' AND start_time < ?", (cutoff,)
    ).fetchall()
    for row in rows:
        try:
            cdir = get_compose_dir(row[1], row[2])
            subprocess.run(["docker", "compose", "down", "-v"], cwd=cdir, capture_output=True)
        except Exception: pass
        conn.execute("UPDATE lab_instances SET status='Destroyed', container_id=NULL WHERE id=?", (row[0],))
    conn.commit()
    conn.close()

scheduler = BackgroundScheduler()
scheduler.add_job(expire_labs, 'interval', minutes=5)
scheduler.start()

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    conn = get_db()
    row = conn.execute("SELECT email FROM users WHERE email=? AND password_hash=?",
                       (data['email'], hash_pwd(data['password']))).fetchone()
    conn.close()
    if not row: return jsonify({'error': 'Invalid credentials'}), 401
    token = secrets.token_hex(32)
    conn = get_db()
    conn.execute("INSERT INTO sessions VALUES (?,?,?)", (token, row[0], datetime.datetime.now().timestamp()))
    conn.commit(); conn.close()
    return jsonify({'token': token, 'user': {'email': row[0]}})

@app.route('/labs', methods=['GET'])
def get_labs():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not verify_token(token): return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    rows = conn.execute("SELECT id,name,difficulty,estimated_duration FROM labs").fetchall()
    conn.close()
    return jsonify([{'id': r[0], 'name': r[1], 'difficulty': r[2], 'estimatedDuration': r[3]} for r in rows])

@app.route('/labs/<int:lab_id>', methods=['GET'])
def get_lab(lab_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not verify_token(token): return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    row = conn.execute("SELECT * FROM labs WHERE id=?", (lab_id,)).fetchone()
    conn.close()
    if not row: return jsonify({'error': 'Not found'}), 404
    return jsonify({'id': row[0], 'name': row[1], 'difficulty': row[2], 'description': row[3],
                    'tools': json.loads(row[4] or '[]'), 'howToUse': row[5], 'estimatedDuration': row[6]})

@app.route('/labs/<int:lab_id>/launch', methods=['POST'])
def launch_lab(lab_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    email = verify_token(token)
    if not email: return jsonify({'error': 'Unauthorized'}), 401

    conn = get_db()
    existing = conn.execute(
        "SELECT status, port, kali_password, start_time FROM lab_instances WHERE lab_id=? AND user_email=?",
        (lab_id, email)
    ).fetchone()

    # Reuse port/password if resuming stopped lab
    if existing and existing[0] == 'Stopped' and existing[1]:
        port = existing[1]
        kali_password = existing[2]
        start_time = existing[3]
    else:
        port = find_free_port()
        kali_password = secrets.token_urlsafe(12)
        start_time = datetime.datetime.now().timestamp()

    cdir = get_compose_dir(lab_id, email)
    os.makedirs(cdir, exist_ok=True)
    compose_content = COMPOSE_TEMPLATE.format(port=port, password=kali_password)
    with open(os.path.join(cdir, "docker-compose.yml"), "w") as f:
        f.write(compose_content)

    container_id = None
    try:
        result = subprocess.run(
            ["docker", "compose", "up", "-d"],
            cwd=cdir, capture_output=True, text=True, timeout=120
        )
        if result.returncode != 0:
            print(f"Compose error: {result.stderr}")
        else:
            # Get container id
            ps = subprocess.run(
                ["docker", "compose", "ps", "-q"],
                cwd=cdir, capture_output=True, text=True
            )
            container_id = ps.stdout.strip()[:12] if ps.stdout.strip() else None
    except Exception as e:
        print(f'Compose error: {e}')

    conn.execute(
        "INSERT OR REPLACE INTO lab_instances (lab_id,user_email,container_id,status,start_time,port,kali_password) VALUES (?,?,?,'Running',?,?,?)",
        (lab_id, email, container_id, start_time, port, kali_password)
    )
    conn.commit(); conn.close()
    return jsonify({
        'labId': lab_id, 'userEmail': email, 'status': 'Running',
        'containerId': container_id, 'startTime': start_time,
        'port': port, 'kaliPassword': kali_password
    })

@app.route('/labs/<int:lab_id>/stop', methods=['POST'])
def stop_lab(lab_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    email = verify_token(token)
    if not email: return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    row = conn.execute("SELECT container_id, port, kali_password FROM lab_instances WHERE lab_id=? AND user_email=?", (lab_id, email)).fetchone()
    cdir = get_compose_dir(lab_id, email)
    if os.path.exists(os.path.join(cdir, "docker-compose.yml")):
        try:
            subprocess.run(["docker", "compose", "stop"], cwd=cdir, capture_output=True, timeout=60)
        except Exception: pass
    conn.execute("UPDATE lab_instances SET status='Stopped' WHERE lab_id=? AND user_email=?", (lab_id, email))
    conn.commit(); conn.close()
    return jsonify({'labId': lab_id, 'userEmail': email, 'status': 'Stopped',
                    'containerId': row[0] if row else None, 'port': row[1] if row else None})

@app.route('/labs/<int:lab_id>/destroy', methods=['POST'])
def destroy_lab(lab_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    email = verify_token(token)
    if not email: return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    cdir = get_compose_dir(lab_id, email)
    if os.path.exists(os.path.join(cdir, "docker-compose.yml")):
        try:
            subprocess.run(["docker", "compose", "down", "-v"], cdir, capture_output=True, timeout=60)
        except Exception: pass
    conn.execute("UPDATE lab_instances SET status='Destroyed', container_id=NULL, port=NULL, kali_password=NULL WHERE lab_id=? AND user_email=?", (lab_id, email))
    conn.commit(); conn.close()
    return jsonify({'message': 'Destroyed'})

@app.route('/labs/<int:lab_id>/status', methods=['GET'])
def lab_status(lab_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    email = verify_token(token)
    if not email: return jsonify({'error': 'Unauthorized'}), 401
    conn = get_db()
    row = conn.execute("SELECT status,container_id,start_time,port,kali_password FROM lab_instances WHERE lab_id=? AND user_email=?",
                       (lab_id, email)).fetchone()
    conn.close()
    if not row: return jsonify({'labId': lab_id, 'userEmail': email, 'status': 'Idle'})
    return jsonify({
        'labId': lab_id, 'userEmail': email, 'status': row[0],
        'containerId': row[1], 'startTime': row[2],
        'port': row[3], 'kaliPassword': row[4]
    })

if __name__ == '__main__':
    os.makedirs(COMPOSE_DIR, exist_ok=True)
    init_db()
    print("CyberRange backend running at http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)`;

const SECTIONS = [
  {
    id: "prerequisites",
    icon: Package,
    title: "1. Prerequisites",
    steps: [
      {
        label: "Verify Python version (3.8+ required)",
        code: "python3 --version",
      },
      { label: "Verify Docker is installed", code: "docker --version" },
      {
        label: "Install Python dependencies",
        code: "pip install flask flask-cors apscheduler",
      },
    ],
  },
  {
    id: "run",
    icon: Play,
    title: "2. Run the Backend",
    steps: [
      {
        label: "Save the full backend code as app.py (see below)",
        code: "# Copy the full Python code and save as app.py",
      },
      { label: "Start the server", code: "python3 app.py" },
      {
        label: "Verify server is running",
        code: "curl http://localhost:5000/labs -H 'Authorization: Bearer invalid'",
      },
    ],
  },
  {
    id: "docker",
    icon: Server,
    title: "3. Docker Commands",
    steps: [
      {
        label: "Start Docker Desktop first",
        code: "# On macOS: open -a Docker\n# On Linux: sudo systemctl start docker",
      },
      {
        label: "Pull Kali Linux image (recommended before first launch)",
        code: "docker pull lscr.io/linuxserver/kali-linux:latest",
      },
      {
        label: "List running Kali lab containers",
        code: "docker ps --filter name=kali-desktop",
      },
      {
        label: "Stop all Kali lab containers manually",
        code: "docker compose -f kali_labs/lab_*/docker-compose.yml down",
      },
    ],
  },
  {
    id: "database",
    icon: Database,
    title: "4. Database & Credentials",
    steps: [
      { label: "Open SQLite database", code: "sqlite3 cyberrange.db" },
      { label: "List all users", code: ".tables\nSELECT email FROM users;" },
      {
        label: "Demo login credentials",
        code: "admin@cyberrange.io / Admin@123\nuser@cyberrange.io  / User@123",
      },
    ],
  },
];

function CopyBtn({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={() => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }}
      className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono transition-all flex-shrink-0"
      style={{
        background: "oklch(0.19 0.045 235)",
        color: copied ? "oklch(0.75 0.15 160)" : "oklch(0.57 0.05 240)",
      }}
    >
      {copied ? (
        <CheckCheck className="w-3 h-3" />
      ) : (
        <Copy className="w-3 h-3" />
      )}
      {copied ? "Copied!" : "Copy"}
    </button>
  );
}

export default function SetupPage() {
  const [fullCopied, setFullCopied] = useState(false);

  return (
    <div
      className="flex min-h-screen"
      style={{ background: "oklch(0.085 0.022 240)" }}
    >
      <Sidebar activePage="setup" />
      <main className="flex-1 ml-64 flex flex-col">
        <header
          className="sticky top-0 z-10 flex items-center px-8 py-4"
          style={{
            background: "oklch(0.085 0.022 240 / 0.95)",
            borderBottom: "1px solid oklch(0.28 0.055 240)",
            backdropFilter: "blur(8px)",
          }}
        >
          <div>
            <h1
              className="text-xl font-bold"
              style={{ color: "oklch(0.92 0.02 240)" }}
            >
              Local Setup Guide
            </h1>
            <p className="text-xs" style={{ color: "oklch(0.57 0.05 240)" }}>
              Run CyberRange on your machine with real Docker containers
            </p>
          </div>
        </header>

        <div className="flex-1 px-8 py-6 max-w-4xl space-y-5">
          {/* Architecture note */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl p-5"
            style={{
              background: "oklch(0.80 0.13 200 / 0.08)",
              border: "1px solid oklch(0.80 0.13 200 / 0.3)",
            }}
          >
            <div className="flex items-center gap-3 mb-2">
              <Terminal
                className="w-5 h-5"
                style={{ color: "oklch(0.80 0.13 200)" }}
              />
              <h2
                className="font-semibold"
                style={{ color: "oklch(0.80 0.13 200)" }}
              >
                Architecture
              </h2>
            </div>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "oklch(0.70 0.04 240)" }}
            >
              Python Flask backend → SQLite auth → Docker SDK (ubuntu:22.04
              containers) → APScheduler auto-expire at 2h. Frontend at{" "}
              <code
                className="font-mono text-xs px-1 rounded"
                style={{
                  background: "oklch(0.14 0.032 238)",
                  color: "oklch(0.80 0.13 200)",
                }}
              >
                http://localhost:5173
              </code>{" "}
              connects to backend at{" "}
              <code
                className="font-mono text-xs px-1 rounded"
                style={{
                  background: "oklch(0.14 0.032 238)",
                  color: "oklch(0.80 0.13 200)",
                }}
              >
                http://localhost:5000
              </code>
              .
            </p>
          </motion.div>

          {SECTIONS.map((section, si) => (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: si * 0.07 }}
              className="rounded-2xl overflow-hidden"
              style={{
                background: "oklch(0.14 0.032 238)",
                border: "1px solid oklch(0.28 0.055 240)",
              }}
            >
              <div
                className="flex items-center gap-3 px-5 py-4"
                style={{ borderBottom: "1px solid oklch(0.28 0.055 240)" }}
              >
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: "oklch(0.80 0.13 200 / 0.15)" }}
                >
                  <section.icon
                    className="w-4 h-4"
                    style={{ color: "oklch(0.80 0.13 200)" }}
                  />
                </div>
                <h2
                  className="font-semibold"
                  style={{ color: "oklch(0.92 0.02 240)" }}
                >
                  {section.title}
                </h2>
              </div>
              <div className="p-5 space-y-3">
                {section.steps.map((step) => (
                  <div key={step.label}>
                    <div
                      className="text-xs mb-1.5"
                      style={{ color: "oklch(0.57 0.05 240)" }}
                    >
                      {step.label}
                    </div>
                    <div
                      className="flex items-start gap-3 rounded-lg px-4 py-3"
                      style={{
                        background: "oklch(0.085 0.022 240)",
                        border: "1px solid oklch(0.28 0.055 240)",
                      }}
                    >
                      <pre
                        className="font-mono text-xs leading-relaxed flex-1"
                        style={{ color: "oklch(0.75 0.15 160)" }}
                      >
                        {step.code}
                      </pre>
                      <CopyBtn text={step.code} />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}

          {/* Full code block */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="rounded-2xl overflow-hidden"
            style={{
              background: "oklch(0.14 0.032 238)",
              border: "1px solid oklch(0.28 0.055 240)",
            }}
          >
            <div
              className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: "1px solid oklch(0.28 0.055 240)" }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: "oklch(0.75 0.15 160 / 0.15)" }}
                >
                  <Terminal
                    className="w-4 h-4"
                    style={{ color: "oklch(0.75 0.15 160)" }}
                  />
                </div>
                <div>
                  <h2
                    className="font-semibold"
                    style={{ color: "oklch(0.92 0.02 240)" }}
                  >
                    Complete Backend: app.py
                  </h2>
                  <p
                    className="text-xs"
                    style={{ color: "oklch(0.57 0.05 240)" }}
                  >
                    Save as app.py, then run: python3 app.py
                  </p>
                </div>
              </div>
              <button
                type="button"
                data-ocid="setup.copy_code.button"
                onClick={() => {
                  navigator.clipboard.writeText(PYTHON_BACKEND);
                  setFullCopied(true);
                  setTimeout(() => setFullCopied(false), 2000);
                }}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold uppercase tracking-wider transition-all"
                style={{
                  background: fullCopied
                    ? "oklch(0.75 0.15 160 / 0.2)"
                    : "linear-gradient(135deg, oklch(0.75 0.15 160), oklch(0.82 0.15 160))",
                  color: fullCopied
                    ? "oklch(0.75 0.15 160)"
                    : "oklch(0.085 0.022 240)",
                }}
              >
                {fullCopied ? (
                  <CheckCheck className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
                {fullCopied ? "Copied!" : "Copy All"}
              </button>
            </div>
            <div>
              <div
                className="flex items-center gap-2 px-5 py-2"
                style={{
                  background: "oklch(0.085 0.022 240)",
                  borderBottom: "1px solid oklch(0.28 0.055 240)",
                }}
              >
                <div
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: "oklch(0.53 0.17 25)" }}
                />
                <div
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: "oklch(0.72 0.14 75)" }}
                />
                <div
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: "oklch(0.75 0.15 160)" }}
                />
                <span
                  className="font-mono text-xs ml-2"
                  style={{ color: "oklch(0.40 0.04 240)" }}
                >
                  app.py — Flask + SQLite + Docker
                </span>
              </div>
              <pre
                className="font-mono text-xs leading-relaxed p-5 overflow-x-auto"
                style={{
                  color: "oklch(0.75 0.15 160)",
                  background: "oklch(0.085 0.022 240)",
                  maxHeight: "560px",
                  overflowY: "auto",
                }}
              >
                {PYTHON_BACKEND}
              </pre>
            </div>
          </motion.div>
        </div>

        <footer
          className="px-8 py-4 border-t text-center"
          style={{ borderColor: "oklch(0.28 0.055 240)" }}
        >
          <p className="text-xs" style={{ color: "oklch(0.40 0.04 240)" }}>
            © {new Date().getFullYear()}. Built with ❤ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noreferrer"
              style={{ color: "oklch(0.80 0.13 200)" }}
            >
              caffeine.ai
            </a>{" "}
            · SYSTEM OPERATIONAL
          </p>
        </footer>
      </main>
    </div>
  );
}
