import { Toaster } from "@/components/ui/sonner";
import { useEffect, useState } from "react";
import AdminPage from "./pages/AdminPage";
import DashboardPage from "./pages/DashboardPage";
import LabDetailPage from "./pages/LabDetailPage";
import LoginPage from "./pages/LoginPage";
import SetupPage from "./pages/SetupPage";

export type Route =
  | { name: "login" }
  | { name: "dashboard" }
  | { name: "lab"; labId: bigint }
  | { name: "setup" }
  | { name: "admin" };

export function navigate(route: Route) {
  if (route.name === "login") window.history.pushState({}, "", "/login");
  else if (route.name === "dashboard")
    window.history.pushState({}, "", "/dashboard");
  else if (route.name === "lab")
    window.history.pushState({}, "", `/lab/${route.labId}`);
  else if (route.name === "setup") window.history.pushState({}, "", "/setup");
  else if (route.name === "admin") window.history.pushState({}, "", "/admin");
  window.dispatchEvent(new PopStateEvent("popstate"));
}

function parseRoute(): Route {
  const path = window.location.pathname;
  if (path.startsWith("/lab/")) {
    const id = path.split("/lab/")[1];
    return { name: "lab", labId: BigInt(id || "1") };
  }
  if (path === "/dashboard") return { name: "dashboard" };
  if (path === "/setup") return { name: "setup" };
  if (path === "/admin") return { name: "admin" };
  return { name: "login" };
}

export default function App() {
  const [route, setRoute] = useState<Route>(parseRoute);

  useEffect(() => {
    const handler = () => setRoute(parseRoute());
    window.addEventListener("popstate", handler);
    return () => window.removeEventListener("popstate", handler);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("cr_token");
    if (!token && route.name !== "login") {
      navigate({ name: "login" });
    } else if (token && route.name === "login") {
      navigate({ name: "dashboard" });
    }
  }, [route.name]);

  return (
    <>
      {route.name === "login" && <LoginPage />}
      {route.name === "dashboard" && <DashboardPage />}
      {route.name === "lab" && <LabDetailPage labId={route.labId} />}
      {route.name === "setup" && <SetupPage />}
      {route.name === "admin" && <AdminPage />}
      <Toaster position="top-right" theme="dark" />
    </>
  );
}
