import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type {
  LabDetail,
  LabInstance,
  LabSummary,
  User,
  UserStats,
} from "../backend.d";
import { LabDifficulty, LabStatus } from "../backend.d";
import { useActor } from "./useActor";

function getToken(): string {
  return localStorage.getItem("cr_token") || "";
}

export function useGetLabs() {
  const { actor, isFetching } = useActor();
  return useQuery<LabSummary[]>({
    queryKey: ["labs"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getLabs(getToken());
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetLabDetail(labId: bigint) {
  const { actor, isFetching } = useActor();
  return useQuery<LabDetail>({
    queryKey: ["lab", labId.toString()],
    queryFn: async () => {
      if (!actor) throw new Error("No actor");
      return actor.getLabDetail(getToken(), labId);
    },
    enabled: !!actor && !isFetching && labId > 0n,
  });
}

export function useGetLabStatus(labId: bigint, enabled: boolean) {
  const { actor, isFetching } = useActor();
  return useQuery<LabInstance>({
    queryKey: ["lab-status", labId.toString()],
    queryFn: async () => {
      if (!actor) throw new Error("No actor");
      return actor.getLabStatus(getToken(), labId);
    },
    enabled: !!actor && !isFetching && enabled,
    refetchInterval: (query) => {
      const data = query.state.data;
      if (
        data &&
        (data.status === LabStatus.Running || data.status === LabStatus.Stopped)
      )
        return 10000;
      return false;
    },
  });
}

export function useLaunchLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<LabInstance, Error, bigint>({
    mutationFn: async (labId) => {
      if (!actor) throw new Error("No actor");
      return actor.launchLab(getToken(), labId);
    },
    onSuccess: (data) => {
      qc.setQueryData(["lab-status", data.labId.toString()], data);
      qc.invalidateQueries({ queryKey: ["my-lab-statuses"] });
      qc.invalidateQueries({ queryKey: ["user-stats"] });
    },
  });
}

export function useStopLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<LabInstance, Error, bigint>({
    mutationFn: async (labId) => {
      if (!actor) throw new Error("No actor");
      return actor.stopLab(getToken(), labId);
    },
    onSuccess: (data) => {
      qc.setQueryData(["lab-status", data.labId.toString()], data);
      qc.invalidateQueries({ queryKey: ["my-lab-statuses"] });
      qc.invalidateQueries({ queryKey: ["user-stats"] });
    },
  });
}

export function useDestroyLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<void, Error, bigint>({
    mutationFn: async (labId) => {
      if (!actor) throw new Error("No actor");
      return actor.destroyLab(getToken(), labId);
    },
    onSuccess: (_, labId) => {
      qc.setQueryData(["lab-status", labId.toString()], {
        labId,
        status: LabStatus.Destroyed,
        userEmail: "",
      });
      qc.invalidateQueries({ queryKey: ["my-lab-statuses"] });
      qc.invalidateQueries({ queryKey: ["user-stats"] });
    },
  });
}

export function useGetAllMyLabStatuses() {
  const { actor, isFetching } = useActor();
  return useQuery<LabInstance[]>({
    queryKey: ["my-lab-statuses"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllMyLabStatuses(getToken());
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

export function useGetUserStats() {
  const { actor, isFetching } = useActor();
  return useQuery<UserStats>({
    queryKey: ["user-stats"],
    queryFn: async () => {
      if (!actor) throw new Error("No actor");
      return actor.getUserStats(getToken());
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 10000,
  });
}

// ─── Admin hooks ────────────────────────────────────────────────────────────

export function useAdminGetAllUsers() {
  const { actor, isFetching } = useActor();
  return useQuery<User[]>({
    queryKey: ["admin-users"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.adminGetAllUsers(getToken());
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAdminGetAllLabInstances() {
  const { actor, isFetching } = useActor();
  return useQuery<LabInstance[]>({
    queryKey: ["admin-lab-instances"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.adminGetAllLabInstances(getToken());
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 15000,
  });
}

export function useAdminCreateUser() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<User, Error, { email: string; password: string }>({
    mutationFn: async ({ email, password }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminCreateUser(getToken(), email, password);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });
}

export function useAdminUpdateUser() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<User, Error, { email: string; newPassword: string }>({
    mutationFn: async ({ email, newPassword }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminUpdateUser(getToken(), email, newPassword);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });
}

export function useAdminDeleteUser() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<void, Error, string>({
    mutationFn: async (email) => {
      if (!actor) throw new Error("No actor");
      return actor.adminDeleteUser(getToken(), email);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    },
  });
}

export function useAdminLaunchLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<LabInstance, Error, { userEmail: string; labId: bigint }>({
    mutationFn: async ({ userEmail, labId }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminLaunchLab(getToken(), userEmail, labId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-lab-instances"] });
    },
  });
}

export function useAdminStopLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<LabInstance, Error, { userEmail: string; labId: bigint }>({
    mutationFn: async ({ userEmail, labId }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminStopLab(getToken(), userEmail, labId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-lab-instances"] });
    },
  });
}

export function useAdminDestroyLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<void, Error, { userEmail: string; labId: bigint }>({
    mutationFn: async ({ userEmail, labId }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminDestroyLab(getToken(), userEmail, labId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-lab-instances"] });
    },
  });
}

export function useAdminCreateLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<
    LabDetail,
    Error,
    {
      name: string;
      difficulty: LabDifficulty;
      description: string;
      howToUse: string;
      estimatedDuration: number;
      tools: Array<{ name: string; description: string }>;
    }
  >({
    mutationFn: async ({
      name,
      difficulty,
      description,
      howToUse,
      estimatedDuration,
      tools,
    }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminCreateLab(
        getToken(),
        name,
        difficulty,
        description,
        howToUse,
        BigInt(estimatedDuration),
        tools,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["labs"] });
    },
  });
}

export function useAdminUpdateLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<
    LabDetail,
    Error,
    {
      labId: bigint;
      name: string;
      difficulty: LabDifficulty;
      description: string;
      howToUse: string;
      estimatedDuration: number;
      tools: Array<{ name: string; description: string }>;
    }
  >({
    mutationFn: async ({
      labId,
      name,
      difficulty,
      description,
      howToUse,
      estimatedDuration,
      tools,
    }) => {
      if (!actor) throw new Error("No actor");
      return actor.adminUpdateLab(
        getToken(),
        labId,
        name,
        difficulty,
        description,
        howToUse,
        BigInt(estimatedDuration),
        tools,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["labs"] });
    },
  });
}

export function useAdminDeleteLab() {
  const { actor } = useActor();
  const qc = useQueryClient();
  return useMutation<void, Error, bigint>({
    mutationFn: async (labId) => {
      if (!actor) throw new Error("No actor");
      return actor.adminDeleteLab(getToken(), labId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["labs"] });
    },
  });
}

// Re-export LabDifficulty for convenience in admin pages
export { LabDifficulty };
